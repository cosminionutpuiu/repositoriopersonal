var urlMapea = "http://www.juntadeandalucia.es/sandetel/publicacion/mapea3";
//var urlMapea = "http://mapea-sigc.juntadeandalucia.es";
var contextos = "wmcfile=http://www.callejerodeandalucia.es/wmc/context_cdau_callejero.xml*Callejero,http://www.callejerodeandalucia.es/wmc/context_cdau_satelite.xml*Ortofoto";
var layers = "WMS*Fuentes*http://www.juntadeandalucia.es/institutodeestadisticaycartografia/geoserver-ieca/conocetusfuentes/wms?*fuentesymanantiales*true*false";
var urlGeosearch = "http://geobusquedas-sigc.juntadeandalucia.es/geobusquedas/fuentesymanantiales/search_html?fq=-(keywords:provincia)";
var extra = "geosearchbylocation=" + urlGeosearch + "*500&controls=location";

