 #! /bin/bash
cd $1
cordova platform remove android
cordova platform add android
cp ../ant.properties ./platforms/android/
cordova build android --release
cp platforms/android/ant-build/CordovaApp-release.apk ../$1.apk
echo "============================"
echo "$1.apk generada"
echo "============================"

