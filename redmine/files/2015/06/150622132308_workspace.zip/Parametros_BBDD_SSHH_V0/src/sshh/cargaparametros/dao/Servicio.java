package sshh.cargaparametros.dao;

import java.util.List;

public class Servicio {

	private String servicio;
	private String operacion;
	private String actividad;
	private List<Parametro> listaParametros;
	private String tarea;
	
	public Servicio (){
		
		
	}
	public  Servicio (String servicio,String operacion, String actividad,List<Parametro> listaParametros,String tarea){
		this.servicio=servicio;
		this.operacion=operacion;
		this.actividad=actividad;
		this.listaParametros=listaParametros;
		this.tarea=tarea;
	}
	public String getTarea() {
		return tarea;
	}
	public void setTarea(String tarea) {
		this.tarea = tarea;
	}
	public String getServicio() {
		return servicio;
	}
	public void setServicio(String servicio) {
		this.servicio = servicio;
	}
	public String getOperacion() {
		return operacion;
	}
	public void setOperacion(String operacion) {
		this.operacion = operacion;
	}
	public String getActividad() {
		return actividad;
	}
	public void setActividad(String actividad) {
		this.actividad = actividad;
	}
	public List<Parametro> getListaParametros() {
		return listaParametros;
	}
	public void setListaParametros(List<Parametro> listaParametros) {
		this.listaParametros = listaParametros;
	}

	
}
