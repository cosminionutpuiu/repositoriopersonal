package sshh.cargaparametros.dao;

import java.util.Date;

public class Parametro {

	private String nombre;
	private String obligatorio;
	private String inhabilitado;
	private Date fechaInicio;
	private Date fechaFinal;

	public Date getFechaInicio() {
		return fechaInicio;
	}
	public void setFechaInicio(Date fechaInicio) {
		this.fechaInicio = fechaInicio;
	}
	public Date getFechaFinal() {
		return fechaFinal;
	}
	public void setFechaFinal(Date fechaFinal) {
		this.fechaFinal = fechaFinal;
	}
	public Parametro (){
		
		
	}
	public  Parametro (String nombre,String obligatorio, String inhabilitado){
		this.nombre=nombre;
		this.obligatorio=obligatorio;
		this.obligatorio=obligatorio;
	}

	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}
	public String getObligatorio() {
		return obligatorio;
	}
	public void setObligatorio(String obligatorio) {
		this.obligatorio = obligatorio;
	}
	public String getInhabilitado() {
		return inhabilitado;
	}
	public void setInhabilitado(String inhabilitado) {
		this.inhabilitado = inhabilitado;
	}

	
}
