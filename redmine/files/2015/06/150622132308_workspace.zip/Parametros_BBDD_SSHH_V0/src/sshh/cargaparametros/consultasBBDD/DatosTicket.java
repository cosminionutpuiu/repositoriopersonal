package sshh.cargaparametros.consultasBBDD;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import sshh.cargaparametros.dao.Parametro;

public class DatosTicket {

	public DatosTicket() {
	}

	private static Log log = LogFactory.getLog(DatosTicket.class);

	/**
	 * Contruye un objeto con los datos del ticket con id igual al pasado como
	 * parametro
	 * 
	 * @param id
	 *            Id del ticket del cual queremos obtener informaci�n
	 */
	public ArrayList<String> SDBDCargaDatosTique(String idIncidencia)
			throws ClassNotFoundException {

		ArrayList<String> datosTique = new ArrayList<String>();

		String sql = "select s.id_itservice SERVICIO,o.id_operation OPERACION from sdk_incident i, sdk_itservice s,sdk_operation o where "
				+ "i.nu_fkitservice=s.id_itservice and "
				+ "i.nu_fkoperation=o.id_operation and "
				+ "i.id_incident="
				+ "'" + idIncidencia + "'";

		ResultSet rss = null;
		Statement stmtr = Oracle.getConexionBBDD();

		try {

			rss = stmtr.executeQuery(sql);

			log.info("Muestra la query: " + sql);

			if (rss == null) {
				log.error("EL ResultSet ES NULO");
			}

			while (rss.next()) {
				datosTique.add(rss.getString("SERVICIO"));
				datosTique.add(rss.getString("OPERACION"));

			}

		} catch (SQLException e) {
			log.error("ERROR ACCEDIENDO A LA BASE DE DATOS : " + sql);
			log.error("ERROR BASE DE DATOS1 : " + e.getErrorCode());
			log.error("ERROR BASE DE DATOS2 : " + e.getMessage());
			log.error("ERROR BASE DE DATOS2 : " + e.getSQLState());
		}

		try {
			stmtr.close();
		} catch (SQLException e) {
			log.error("ERROR ACCEDIENDO AL ResultSet para cerrar la conexion");
		}
		return datosTique;
	}

	public ArrayList<Parametro> obtenerParametros(String idServicio,
			String idOperacion, String tarea, Long idIncidencia) {

		ArrayList<Parametro> listaParametros = new ArrayList<Parametro>();

		String sql = "select p.id_parametros ID_PARAMETRO,p.nombre NOMBRE,p.obligatorio OBLIGATORIO,p.inhabilitado INHABILITADO,p.tx_orden ORDEN from parametros p,criterios_parametros cp"
				+ " where p.nu_fkcriterios=cp.id_criterio and"
				+ " p.nu_fkcriterios="
				+ " (select cp2.id_criterio from criterios_parametros cp2 where"
				+ " cp2.id_servicio="
				+ "'"
				+ idServicio
				+ "'"
				+ " and cp2.id_operacion="
				+ "'"
				+ idOperacion
				+ "'"
				+ " and cp2.tx_tarea="
				+ "'"
				+ tarea
				+ "'"
				+ " and cp.id_serviceversion="
				+ " (SELECT  MAX (SP.NU_FKSERVICEVERSION) FROM SDK_INCIDENT SI, SDK_PHASESERVICE SP"
				+ " WHERE SI.NU_FKPHASESERVICE=SP.ID_PHASESERVICE AND SI.ID_INCIDENT="
				+ "'" + idIncidencia + "'" + ")) order by 5 asc";

		ResultSet rss = null;

		Statement stmtr = null;
		stmtr = Oracle.getConexionBBDD();

		try {

			rss = stmtr.executeQuery(sql);

			log.info("Muestra la query: " + sql);

			if (rss == null) {
				log.error("EL ResultSet ES NULO");
			}


			while (rss.next()) {
				Parametro parametro = new Parametro();
				parametro.setNombre(rss.getString("NOMBRE"));
				parametro.setObligatorio(rss.getString("OBLIGATORIO"));
				parametro.setInhabilitado(rss.getString("INHABILITADO"));
				listaParametros.add(parametro);

			}

		} catch (SQLException e) {
			log.error("ERROR ACCEDIENDO A LA BASE DE DATOS : " + sql);
			log.error("ERROR BASE DE DATOS1 : " + e.getErrorCode());
			log.error("ERROR BASE DE DATOS2 : " + e.getMessage());
			log.error("ERROR BASE DE DATOS2 : " + e.getSQLState());
		}

		try {
			stmtr.close();
		} catch (SQLException e) {
			log.error("ERROR ACCEDIENDO AL ResultSet");
		}
		return listaParametros;

	}

}
