package sshh.cargaparametros.consultasBBDD;

import java.io.IOException;
import java.sql.*;
import java.util.Properties;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
 class Oracle {
		/** The log. */
		private static Log log = LogFactory.getLog(Oracle.class);
  
	public final static Statement getConexionBBDD() {
		Connection conexion;
		Properties configuracion = new Properties();
		Statement stmt=null;
		try {
			configuracion.load(Oracle.class.getResourceAsStream("DEXTPLUS_accesoBD.properties"));
		} catch (final IOException e) {
			log.error("ERROR ACCEDIENDO AL FICHERO DE PROPIEDADES");
		}

		try {
			try {
				Class.forName("oracle.jdbc.OracleDriver");
			} catch (ClassNotFoundException e) {
				e.printStackTrace();
			}
			conexion = DriverManager.getConnection(configuracion
					.getProperty("sdk_database.url"), configuracion
					.getProperty("sdk_database.user"), configuracion
					.getProperty("sdk_database.password"));

			stmt = conexion.createStatement();
		} catch (SQLException e) {
			log.error("ERROR ACCEDIENDO A LA BASE DE DATOS : " );
			log.error("ERROR BASE DE DATOS1 : " + e.getErrorCode());
			log.error("ERROR BASE DE DATOS2 : " + e.getMessage());
			log.error("ERROR BASE DE DATOS2 : " + e.getSQLState());
		}

		return stmt;
	}
 } 
 
