package es.juntadeandalucia.servicedesk.external;

import java.util.ArrayList;
import java.util.List;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import sshh.cargaparametros.consultasBBDD.DatosTicket;
import sshh.cargaparametros.dao.Parametro;

import es.juntadeandalucia.servicedesk.external.type.DataTaskField;

public class SSHHPARV0 extends DataTaskExternal {

	private static Log log = LogFactory.getLog(SSHHPARV0.class);

	@Override
	public List<DataTaskField> getParameters(String tarea) {
		log.info("Entramos en la tarea: " + tarea);

		List<DataTaskField> LISTA_PARAM = new ArrayList<DataTaskField>();

		String servicioTicket = "";
		String operacionTicket = "";
		ArrayList<String> listadodatosTicket = new ArrayList<String>();
		DatosTicket datosTicket = new DatosTicket();
		String idIncidencia = Long.toString(incidentId);
		log.info("Id del ticket: " + idIncidencia);

		// Datos ticket
		try {
			listadodatosTicket = datosTicket.SDBDCargaDatosTique(idIncidencia);
			servicioTicket = listadodatosTicket.get(0);
			operacionTicket = listadodatosTicket.get(1);

		} catch (ClassNotFoundException e1) {
			log.error("No se encuentra la clase sshh.cargaparametros.consultasBBDD.DatosTicket");
			e1.printStackTrace();
		}

		log.info("Servicio del ticket: " + servicioTicket);
		log.info("Operaci�n del ticket: " + operacionTicket);

		ArrayList<Parametro> listaParametros = new ArrayList<Parametro>();

		listaParametros = datosTicket.obtenerParametros(servicioTicket,operacionTicket, tarea, incidentId);

		if (listaParametros.size() > 0) {
			for (Parametro parametro : listaParametros) {// Iteramos por los parametros definidos en BD
				for (DataTaskField d : incidentParams) {// Iteramos por los parametros que vienen en el procedimiento
					if ((d.getName()).equals(parametro.getNombre())) {
						if (parametro.getInhabilitado().equalsIgnoreCase("1")) {
							d.setDisabled(true);
						}
						if (parametro.getObligatorio().equalsIgnoreCase("1")) {
							d.setMandatory(true);
						}
						LISTA_PARAM.add(d);
					}
				}

			}
		}

		return LISTA_PARAM;
	}

	@Override
	public void postTransaction(String transicion) {

		log.info(">>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> ENTRAMOS EN EL METODO postTransaction");

		log.info(">>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> ENTRAMOS EN LA TRANSICION: "+ transicion);

	}

	@Override
	public boolean preTransaction(String arg0) {
		return true;
	}

	@Override
	public boolean saveTask(String tarea, List<DataTaskField> arg1) {
		return true;
	}

}
