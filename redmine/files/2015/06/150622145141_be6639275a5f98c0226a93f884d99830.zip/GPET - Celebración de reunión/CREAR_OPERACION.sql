--Operacion reunion
INSERT INTO SDK_OPERATION 
(ID_OPERATION,TX_CODE,TX_NAME,DS_DESCRIPTION,NU_FKITPROCESS,
NU_FKCI,LG_ACTIVE,TX_IMAGE)
VALUES (SDK_SQ_OPERATION.NEXTVAL,'Convocar reuni�n','Convocar reuni�n','Atender solicitud de celebraci�n de una reuni�n',
(select ID_ITPROCESS from SDK_ITPROCESS where TX_CODE='G_PETICIONES'),null,1,'G_PETICIONES.png'); 


commit;

