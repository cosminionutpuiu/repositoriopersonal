# $1 ruta al WAR que hay que descomprimir (ejemplo: /path/to/WAR/nombrePaquete.war)
# $2 directorio en el que se descomprimirá el WAR, el directorio se borrará si existe y se creará (ejemplo: /path/to/unpackaged/WAR)
function unpackageWAR() {
  if [ -d $2 ];
  then
    rm -rf $2
  fi
  mkdir $2;
  unzip $1 -d $2 >/dev/null
}



# $1 directorio que hay que comprimir en formato WAR (ejemplo: /path/to/unpackaged/WAR)
# $2 path y nombre del fichero WAR que se generará. (ejemplo: /path/to/WAR/nombrePaquete.war)
function packageWAR() {
  pushd $1
  zip -r $2 ./* >/dev/null
  popd
  mv $1/$2 ./
}


# funcion que abre un fichero comprimido en formato zip y para cada fichero de configuración cuya ruta se la pasa como parámetro 
# y en cada fichero localiza una serie de patrones que se le pasan en un array sustituyendo cada ocurrencia del array de patrones
# por los valores que también se le pasan en otro array de valores
# $1 nombre del archivo que hay que descomprimir y que está comprimido en formato zip. El nombre del archivo debe tener el siguiente formato e indicará siempre la ruta al fichero tomando como raíz el WAR que se ha descomprimido: "dir1/dir2/dir3/nombreFichero"
# $2 array unidimensional con nombres de los ficheros sobre los que es necesario trabajar
# $3 array unidimensional con todas las claves existentes en el sistema, debe pasarse el array PATRONES_BUSQUEDA
# $4 array unidimensional con todos los valores para cada una de las claves del sistema, debe pasarse el array PATRONES_SUSTITUCION
# $5 realmente no hay un quinto parámetro, el número de parámetros que se pasan es variable ya que lo que se pasa es un array bidimensional cuyas filas representan a cada fichero de configuración y las celdas de cada fila almacenan los patrones que es necesario buscar en el fichero
function generateProcessedWAR(){
	directorioTemporal="temp"
	declare -a filesArray=("${!2}")
	declare -a configProperties=("${!3}")	

	echo "Descomprimiendo WAR: "$1
	mv $1 $1"_bk"
	unpackageWAR $1"_bk" $directorioTemporal
	I=0
	J=0
	#este bucle es para procesar el quinto parámetro que al ser un array bidimensional es pasado como N parametros tantos como filas, con $* accedemos a toda la lista de parámetros, por eso ignoramos las 4 primeras iteraciones
    for inParameter in $*
	do
		if (( $I>3 )); then
			# la fila i pasada como parámetro a esta función representan los patrones que hay que buscar en el fichero cuyo indice es i
			filename=${filesArray[$J]} #nombre del fichero de configuracion
			generateProcessedFile $directorioTemporal"/"$filename $3 $4 `echo $inParameter | tr : " "`
			((J++))
		fi	
		((I++))
	done

	packageWAR $directorioTemporal $1
	rm $1"_bk"

}

# función que dado el nombre de un fichero, indicado por su ruta relativa, recibe los pares clave-valor de configuración y un array para indicar qué pares aplican para dicho fichero y realiza la sustitución correspondiente en el mismo
# $1 ruta del fichero
# $2 array con los patrones generales definidos
# $3 array con los valores generales definidos
# $4 array que almacena los patrones que aplican realmente para este fichero
function generateProcessedFile(){
	# a continuación el bucle que recorre el array con las propiedades para dicho fichero de configuracion
	I=0
	for property in $*
	do
		if (( $I>2 )); then
			resultado=$(getValueForPattern $property $2 $3)
			sustituirTodasOcurrenciasCadenaEnFichero $property $resultado $1
		fi
		((I++))
	done
}

# función a la que se le pasa como primer parámetro un array y como segundo parámetro un valor
# la función localiza la posición del valor en el array y la devuelve. Devuelve -1 si no la encuentra
# $1 array en el que se realizará la búsqueda
# $2 elemento a buscar
function indexOf(){
	declare -a arrPatrones=("${!1}")
	I=0	
	index=-1
	for V in "${arrPatrones[@]}"; 
	do
		if [ ${arrPatrones[$I]} = $2 ]; then
			index=$I
			break
		fi
		((I++))
    done
	echo "$index"
}



# función que busca un patron en un array de patrones y devuelve el valor para dicho patron. Para ellos se le pasan dos matrices, una con los patrones y otra con los
# valores de dichos patrones, busca en el array de patrones y tomando el índice devuelto devuelve el valor correspondiente
# $1 cadena patron cuyo valor debe ser devuelto
# $2 array de patrones
# $3 array de valores para los patrones
function getValueForPattern(){
	declare -a arrPatrones=("${!2}")
	declare -a arrValores=("${!3}")
    longitud1=${#arrPatrones[@]}
	longitud2=${#arrValores[@]}
	valor=""
	if [ $longitud1 != $longitud2 ]; then
		echo "No coinciden las longitudes de los arrays pasados como parámetros a 'getValueForPattern'"
		exit
	fi
	indice=$(indexOf $2 $1)
	check=-1
	if [ "$indice" != "$check" ]; then
		valor=${arrValores[$indice]}
	fi
	echo "$valor"
}


