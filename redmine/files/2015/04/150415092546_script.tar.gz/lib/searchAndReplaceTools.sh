# $1 primer parametro de la cadena es el patrón a buscar
# $2 segundo parametro es el valor a sustituir
# $3 tercer parametro es el fichero en el que se realiza la sustitucion
function sustituirUnaOcurrenciaCadenaEnFichero() {
	if [ $1 = "." ] || [ $1 = "\." ]; then
		echo "No puede utilizarse el caracter '.' para buscar al ser un caracter reservado"
		exit
	fi
	sed -i 's#'$1'#'$2'#' $3
}

# $1 primer parametro de la cadena es el patrón a buscar
# $2 segundo parametro es el valor a sustituir
# $3 tercer parametro es el fichero en el que se realiza la sustitucion
function sustituirTodasOcurrenciasCadenaEnFichero(){
	if [ $1 = "." ] || [ $1 = "\." ]; then
		echo "No puede utilizarse el caracter '.' para buscar al ser un caracter reservado"
		exit
	fi
	tercerParametro=$3
	segundoParametro=$2
	if [ $# = 2 ]; then # si el valor del parámetro a sustituir es una cadena vacía el script interpreta que sólo hay dos parámetros y no tres
		tercerParametro=$2
		segundoParametro=""
	fi
	cat $tercerParametro | sed "s#"$1"#"$segundoParametro"#g" > $tercerParametro.bk
	rm $tercerParametro
	mv $tercerParametro.bk $tercerParametro
}

# $1 array con los patrones a buscar
# $2 array con los valores a sustituir
# $3 nombre del fichero en el que se realizará la sustitución
function sustituirTodasOcurrenciasArrayCadenasEnFichero(){
	declare -a argAry1=("${!1}")
	declare -a argAry2=("${!2}")
	longitud1=${#argAry1[@]}
	longitud2=${#argAry2[@]}
	if [ $longitud1 != $longitud2 ]; then
		echo "No coinciden las longitudes de los arrays pasados como parámetros a 'sustituirTodasOcurrenciasArrayCadenasEnFichero'"
		exit
	fi
	I=0	
	for V in "${argAry1[@]}"; 
	do
		sustituirTodasOcurrenciasCadenaEnFichero $V ${argAry2[$I]} $3
		((I++))
    done
}

