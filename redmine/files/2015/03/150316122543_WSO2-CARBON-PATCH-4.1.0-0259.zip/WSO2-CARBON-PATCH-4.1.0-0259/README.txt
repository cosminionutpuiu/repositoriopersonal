Patch ID         : WSO2-CARBON-PATCH-4.1.0-0259
Applies To       : AS 5.1.0
Associated JIRA  : https://wso2.org/jira/browse/ESBJAVA-3059


DESCRIPTION
-----------
This patch fixes error(NullPointerException) while a proxy service is invoked when ActivityMonitoring feature is enabled in ESB


INSTALLATION INSTRUCTIONS
-------------------------

(i)  Shutdown the server, if you have already started.

(ii) Copy the wso2carbon-version.txt file to <CARBON_SERVER>/bin.

(iii) Copy the patch0259 to  <CARBON_SERVER>/repository/components/patches/

(iv) Restart the server with :
       Linux/Unix :  sh wso2server.sh -DapplyPatches
       Windows    :  wso2server.bat -DapplyPatches

