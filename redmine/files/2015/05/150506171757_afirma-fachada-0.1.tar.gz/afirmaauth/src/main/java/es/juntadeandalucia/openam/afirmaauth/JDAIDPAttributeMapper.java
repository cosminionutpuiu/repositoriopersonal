package es.juntadeandalucia.openam.afirmaauth;


import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.StringTokenizer;

import com.sun.identity.plugin.datastore.DataStoreProviderException;
import com.sun.identity.plugin.session.SessionException;
import com.sun.identity.plugin.session.SessionManager;
import com.sun.identity.saml2.assertion.AssertionFactory;
import com.sun.identity.saml2.assertion.Attribute;
import com.sun.identity.saml2.common.SAML2Constants;
import com.sun.identity.saml2.common.SAML2Exception;
import com.sun.identity.saml2.jaxb.entityconfig.BaseConfigType;
import com.sun.identity.saml2.meta.SAML2MetaException;
import com.sun.identity.saml2.meta.SAML2MetaManager;
import com.sun.identity.saml2.meta.SAML2MetaUtils;
import com.sun.identity.saml2.plugins.DefaultAttributeMapper;
import com.sun.identity.saml2.plugins.IDPAttributeMapper;
import com.sun.identity.shared.debug.Debug;
import com.sun.identity.shared.xml.XMLUtils;

public class JDAIDPAttributeMapper extends DefaultAttributeMapper implements IDPAttributeMapper {

	public static final String MODULE_NAME = "Afirma";
	private static Debug debug = Debug.getInstance(MODULE_NAME);
    private static SAML2MetaManager saml2MetaManager = null;
    static {
        try {
            saml2MetaManager =
                    new SAML2MetaManager();
        } catch (SAML2MetaException sme) {
            debug.error("Error retreiving metadata",sme);
        }
    }
	
	public JDAIDPAttributeMapper() {
		// TODO Auto-generated constructor stub
	}

	  /**
     * Returns list of SAML <code>Attribute</code> objects for the 
     * IDP framework to insert into the generated <code>Assertion</code>.
     * 
     * @param session Single sign-on session.
     * @param hostEntityID <code>EntityID</code> of the hosted entity.
     * @param remoteEntityID <code>EntityID</code> of the remote entity.
     * @param realm name of the realm.
     * @exception SAML2Exception if any failure.
     */
	@Override
    public List getAttributes(Object session, String hostEntityID,
        String remoteEntityID, String realm) throws SAML2Exception
    {
 
		debug.message("JDAIDPAttributeMapper getAttributes");
        if (hostEntityID == null) {
            throw new SAML2Exception(bundle.getString("nullHostEntityID"));
        }

        if (realm == null) {
            throw new SAML2Exception(bundle.getString("nullHostEntityID"));
        }
       
        if (session == null) {
            throw new SAML2Exception(bundle.getString("nullSSOToken"));
        }

        try {
            if (!SessionManager.getProvider().isValid(session)) {
                if (debug.warningEnabled()) {
                    debug.warning("DefaultLibraryIDPAttributeMapper." +
                        "getAttributes: Invalid session");
                }
                return null;
            }

            Map configMap = getConfigAttributeMap2(realm, remoteEntityID, SP);
            if (debug.messageEnabled()) {
                debug.message("DefaultLibraryIDPAttributeMapper." +
                    "getAttributes: remote SP attribute map = " + configMap);
            }
            if ((configMap == null) || (configMap.isEmpty())) {
                configMap = getConfigAttributeMap2(realm, hostEntityID, IDP);
                if ((configMap == null) || (configMap.isEmpty())) {
                    if (debug.messageEnabled()) {
                        debug.message("DefaultLibraryIDPAttributeMapper." +
                            "getAttributes: Configuration map is not defined.");
                    }
                    return null;
                }
                if (debug.messageEnabled()) {
                    debug.message("DefaultLibraryIDPAttributeMapper." +
                        "getAttributes: hosted IDP attribute map=" + configMap);
                }
            }

            List attributes = new ArrayList();
            
            Set localAttributes = new HashSet();
            Map valueMap = null; 
            
            
            // localAttributes.addAll(configMap.values());

            
            Collection valores = configMap.values();
           
            
            for (Iterator iterator = valores.iterator(); iterator.hasNext();) {
				String  temp = (String) iterator.next();
				String a2 = "";
				if (temp.indexOf("###")!=-1){
					debug.message("campo en formato patrón -> " + temp);
					temp = new StringTokenizer(temp, "###").nextToken().trim(); // el primero token corresponde con el campo local que queremos...
					debug.message("campo resultante -> " + temp);
				}
				
				debug.message("añadiendo local atribute -> " + temp);
				localAttributes.add(temp);
			}
      

            if (!isDynamicalOrIgnoredProfile(realm)) {
                try {
                    valueMap = dsProvider.getAttributes(
                        SessionManager.getProvider().getPrincipalName(session),
                        localAttributes); 
                } catch (DataStoreProviderException dse) {
                    if (debug.warningEnabled()) {
                        debug.warning("DefaultLibraryIDPAttributeMapper." +
                            "getAttributes:", dse);
                    }
                    //continue to check in ssotoken.
                }
            }

            
            // Se recorre todos los atributos a mapear...
            Iterator iter = configMap.keySet().iterator();
            while(iter.hasNext()) {
                String samlAttribute = (String)iter.next();
                String localAttribute = (String)configMap.get(samlAttribute);
                String nameFormat = null;

                // if samlAttribute has format nameFormat|samlAttribute
                StringTokenizer tokenizer = 
                    new StringTokenizer(samlAttribute, "|");
                if (tokenizer.countTokens() > 1) {
                    nameFormat = tokenizer.nextToken();
                    samlAttribute = tokenizer.nextToken();
                }
                
                
            	//String localAttribute = "JAdni ### N=(.*?);A1=(.*?);A2=(.*?); ### nombre $1 Apellido1 $2 Apellido2 $3";
                
                // sn2 = JAnombreApellidos ### N=(.*?);A1=(.*?);A2=(.*?); ### $2
                
                
                // Codigo para parseo de atributos con valor campo ### patron entrada ### patron salida
            	//String campo =null;
            	String valor =null;
            	
                String patronEntrada =null;
                String patronSalida =null;
                boolean esCampoPatron = false;
                StringTokenizer tokenizer2 = 
                        new StringTokenizer(localAttribute, "###");
                
                    if (tokenizer2.countTokens() == 3) { // Si el valor del campo es del tipo que contiene una expresión regular... 
                    	 debug.message("campo con expresión regular " );
                    	localAttribute = tokenizer2.nextToken().trim();  // El local atribute es el primer parámetro...
                        patronEntrada = tokenizer2.nextToken().trim();
                        patronSalida = tokenizer2.nextToken().trim();
                        //localAttribute = campo;
                        esCampoPatron=true;
                    }
                    
                // Primero busca los valores del campo en los valueMap del dsprovider
                
                String[] localAttributeValues = null;
                if ((valueMap != null) && (!valueMap.isEmpty())) {
                    Set values = (Set)valueMap.get(localAttribute); 
                    if ((values == null) || (values.isEmpty())) {
                        if (debug.messageEnabled()) {
                            debug.message("DefaultLibraryIDPAttributeMapper." +
                                "getAttribute: user profile does not have " +
                                "value for " + localAttribute +
                                " but is going to check ssotoken:");
                        }
                    } else {
                        localAttributeValues = (String[])values.toArray(
                            new String[values.size()]);
                    }
                } 
                if (localAttributeValues == null) {
                    localAttributeValues = SessionManager.
                        getProvider().getProperty(session, localAttribute);
                }

                if ((localAttributeValues == null) ||
                    (localAttributeValues.length == 0)) {

                    if (debug.messageEnabled()) {
                        debug.message("DefaultLibraryIDPAttributeMapper." +
                            "getAttribute: user does not have " +
                            localAttribute);
                    }
                    continue;
                }else if (esCampoPatron){
                	
                	 debug.message("Se pasan los valores del campo por el patones definidos");
                	 
                	for (int i = 0; i < localAttributeValues.length; i++) {
                		debug.message("campo " + localAttribute + " valor original " + localAttributeValues[i]);
                		localAttributeValues[i] = localAttributeValues[i].replaceAll(patronEntrada, patronSalida);
                		debug.message("campo " + localAttribute + " valor procesado " + localAttributeValues[i]);
					}
                } 
                	

                attributes.add(getSAMLAttribute(samlAttribute, nameFormat,
                    localAttributeValues, hostEntityID, remoteEntityID, realm));
            }
            return attributes;      

        } catch (SessionException se) {
            debug.error("DefaultLibraryIDPAttribute.getAttributes: ", se);
            throw new SAML2Exception(se);
        }

    }
	

    /**
     * Decides whether it needs to escape XML special characters for attribute
     * values or not.
     * @param hostEntityID Entity ID for hosted provider.
     * @param remoteEntityID Entity ID for remote provider.
     * @param realm the providers are in.
     * @return <code>true</code> if it should escape special characters for
     *   attribute values; <code>false</code> otherwise.
     */
    protected boolean needToEscapeXMLSpecialCharacters(String hostEntityID,
        String remoteEntityID, String realm)
    {
        return true;
    }

    /**
     * Returns the SAML <code>Attribute</code> object.
     *
     * @param name attribute name.
     * @param nameFormat Name format of the attribute
     * @param values attribute values.
     * @param hostEntityID Entity ID for hosted provider.
     * @param remoteEntityID Entity ID for remote provider.
     * @param realm the providers are in.
     * @return SAML <code>Attribute</code> element.
     * @exception SAML2Exception if any failure.
     */
    protected Attribute getSAMLAttribute(String name, String nameFormat,
         String[] values, String hostEntityID, String remoteEntityID,
         String realm) 
    throws SAML2Exception {

        if (name == null) {
            throw new SAML2Exception(bundle.getString("nullInput"));
        }

        AssertionFactory factory = AssertionFactory.getInstance();
        Attribute attribute =  factory.createAttribute();

        attribute.setName(name);
        if (nameFormat != null) {
            attribute.setNameFormat(nameFormat);
        }
        if (values != null) {
            boolean toEscape = needToEscapeXMLSpecialCharacters(
                hostEntityID, remoteEntityID, realm);
            List list = new ArrayList();
            for (int i=0; i<values.length; i++) {
                if (toEscape) {
                    list.add(XMLUtils.escapeSpecialCharacters(values[i]));
                } else {
                    list.add(values[i]);
                }
            }
            attribute.setAttributeValueString(list);
        }
        return attribute;
    }

    /**
     * Checks if dynamical profile creation or ignore profile is enabled.
     * @param realm realm to check the dynamical profile creation attributes.
     * @return true if dynamical profile creation or ignore profile is enabled,
     * false otherwise.
     */
    protected boolean isDynamicalOrIgnoredProfile(String realm) {
        return false;
    }
    
    
    public static Map getConfigAttributeMap2(String realm, String hostEntityID,
            String role) throws SAML2Exception {

            if (realm == null) {
                throw new SAML2Exception(bundle.getString("nullRealm"));
            }

            if (hostEntityID == null) {
                throw new SAML2Exception(bundle.getString("nullHostEntityID"));
            }

            if (debug.messageEnabled()) {
                debug.message("SAML2Utils.getConfigAttributeMap:" +
                    " DefaultAttrMapper: relam=" + realm + ", entity id=" +
                    hostEntityID + ", role=" + role);
            }
            try {
                BaseConfigType config = null;
                if (role.equals(SAML2Constants.SP_ROLE)) {
                    config = saml2MetaManager.getSPSSOConfig(realm, hostEntityID);
                } else if (role.equals(SAML2Constants.IDP_ROLE)) {
                    config = saml2MetaManager.getIDPSSOConfig(realm, hostEntityID);
                }


                if (config == null) {
                    if (debug.warningEnabled()) {
                        debug.warning("SAML2Utils.getConfigAttributeMap: " +
                            "configuration is not defined.");
                    }
                    return Collections.EMPTY_MAP;
                }

                Map attribConfig = SAML2MetaUtils.getAttributes(config);
                List mappedAttributes = 
                    (List)attribConfig.get(SAML2Constants.ATTRIBUTE_MAP);

                if ((mappedAttributes == null) || (mappedAttributes.size() == 0)) {
                    if (debug.messageEnabled()) {
                        debug.message("SAML2Utils.getConfigAttributeMap:" +
                            "Attribute map is not defined for entity: "+
                            hostEntityID);
                    }
                    return Collections.EMPTY_MAP; 
                }
                Map map = new HashMap();

                for(Iterator iter = mappedAttributes.iterator(); iter.hasNext();) {
                    String entry = (String)iter.next();

                    if (entry.indexOf("=") == -1) {
                        if(debug.messageEnabled()) {
                            debug.message("SAML2Utils.getConfigAttributeMap: " +
                                "Invalid entry." + entry);
                        }
                        continue;
                    }
                    debug.message(" entrada "  + entry);
                    debug.message(" 1 "  + entry.substring(0, entry.indexOf("=")).trim());
                    debug.message(" 2 "  + entry.substring(entry.indexOf("=")+1));
                    
                    map.put(entry.substring(0, entry.indexOf("=")).trim() , entry.substring(entry.indexOf("=")+1).trim());
                    /*
                    StringTokenizer st = new StringTokenizer(entry, "="); 
                    map.put(st.nextToken(), st.nextToken());*/
                }
                return map;

            } catch(SAML2MetaException sme) {
                debug.error("SAML2Utils.getConfigAttributeMap: ", sme);
                throw new SAML2Exception(sme.getMessage());

            }
        }
    
    
    
    
    
}