/**
 * European Union Public License
 * Empresa desarrolladora: SANDETEL
 * Autor: Junta de Andalucia.
 * Fecha Liberacion en 2012.
 *
 * Este programa es software libre: usted tiene derecho a redistribuirlo
 * y/o modificarlo bajo los terminos de la Licencia EUPL European Public
 * License publicada por el organismo IDABC de la Comision Europea, en su
 * version 1.0. o posteriores.
 *
 * Este programa se distribuye de buena fe, pero SIN NINGUNA GARANTIA,
 * incluso sin las presuntas garantias implicitas de USABILIDAD o
 * ADECUACION A PROPOSITO CONCRETO. Para mas informacion consulte la
 * Licencia EUPL European Public License.
 *
 * Usted recibe una copia de la Licencia EUPL European Public License junto
 * con este programa, si por algun motivo no le es posible visualizarla,
 * puede consultarla en la siguiente URL:
 * http://ec.europa.eu/idabc/servlets/Doc?id=31099
 *
 * You should have received a copy of the EUPL European Public License
 * along with this program. If not, see
 * http://ec.europa.eu/idabc/servlets/Doc?id=31096
 *
 * Sie sollten eine Kopie der EUPL European Public License zusammen mit
 * diesem Programm. Wenn nicht, finden Sie da
 * http://ec.europa.eu/idabc/servlets/Doc?id=29919
 */
package es.juntadeandalucia.utils.cripto;

import java.io.BufferedReader;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.OutputStream;
import java.util.Enumeration;
import java.util.Properties;

import org.apache.commons.codec.binary.Base64;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;



public class CifradorProperties {
	
	/** Array con el nombre de los posibles parametros cifrados del fichero de ocnfiguraci�n */
    private static String[] PARAM_CIFRADOS =new String[]{};
    /** Logger */
    private static Log moLog = LogFactory.getLog(CifradorProperties.class);

    
    
    
    public CifradorProperties(String[] params) {
    	PARAM_CIFRADOS = params;
	}

	/**
     * Cifra/descifra los datos sensibles de configuraci�n.<br>
     * Los valores cifrados los graba en el fichero externo de configuraci�n.
     * 
     * @param pmPropiedades Datos de configuraci�n
     * @param psFichero Ruta al fichero de configuraci�n para almacenar datos cifrados.
     */
    public  void cifradoDatosConfiguracon(Properties pmPropiedades, String psFichero) {
    	
    	// Establecer los parametros de configuraci�n susceptibles de ser cifrados.
    	Properties lmPropCifradas = new Properties();
    	
    	
    	// Para cada uno de los parametros comprobar si est� cifrado
		for (int i=0; i<PARAM_CIFRADOS.length;i++) {
    		String lsClave = PARAM_CIFRADOS[i];
    		String lsValor = pmPropiedades.getProperty(lsClave);
    		if ((lsValor == null) || lsValor.trim().equals("")) {
                // No se ha establecido valor => No hacer nada
            } else if (estaCifrado(lsValor.getBytes())) {
                // Ya est� cifrado => Desconvertir Base64, descifrarlo y modificar la propiedad

                String lsValorNeto = lsValor.trim().substring(1, lsValor.length() - 1); // Sin las '{' y '}' que indican el cifrado
                byte[] laDescifrado = null;
                try {
                	laDescifrado = Crypt.descifrar(Base64.decodeBase64(lsValorNeto.getBytes()));
                } catch (Throwable e) {
                	moLog.error("cifradoDatosConfiguracon - Crypt.descifrar",e);
                }

                
                if (laDescifrado != null) {
                	pmPropiedades.setProperty(lsClave, new String(laDescifrado));
                }
            } else {
                // No est� cifrado => Cifrarlo, calcular Base64 y guardarlo en el fichero de config

            	String lsCifrado = null;
            	try {
            		byte[] laCifrado = Crypt.cifrar(lsValor.getBytes());
            		lsCifrado = "{" + new String(Base64.encodeBase64(laCifrado)) + "}";
                } catch (Throwable e) {
                	moLog.error("cifradoDatosConfiguracon - Crypt.cifrar",e);
                }
                
                if (lsCifrado != null) {
                	// Modificar en el fichero config
                	lmPropCifradas.put(lsClave, lsCifrado);
                }
            }
    	} // for de posibles parametros cifrados
    	
    	// Comprobar si modificar fichero
    	if (!lmPropCifradas.isEmpty() && psFichero != null) {
    		modificarFicheroConfig(lmPropCifradas, psFichero);
    	}
    	
    //	return lmPropCifradas;
    }
    
    /**
     * Indica si un dato es un valor cifrado
     * @param datos Valor a chequear
     * @return true si el valor es un dato cifrado
     */
    private static boolean estaCifrado(byte[] datos) {
        if (new String(datos).startsWith("{")) {
            return true;
        }

        return false;
    }
    
    /**
     * Modificar los valores del fichero de configuraci�n de los parametros
     * de las propiedades (<nombre parametro>, <valor a grabar>)
     * @param pmParamModificar Parametros a modificar
     * @param psFichero Fichero de configuraci�n
     */
    private  void modificarFicheroConfig(Properties pmParamModificar, String psFichero) {
		// Modificar las propiedades de lmPropCifradas en fichero de config
		//----------------------------------------------
        // Actualizar fichero de config con las pwd cifradas

        OutputStream loOutFile = null;
        //int i = 0;
        try {
            final String LINE_SEPARATOR = System.getProperty("line.separator");

            StringBuffer lsBuffer = new StringBuffer();
            BufferedReader loIN = new BufferedReader(new FileReader(psFichero));
            String lsLinea = null;

            while ((lsLinea = loIN.readLine()) != null) { // Iterar por la lineas del fichero de config
            	Enumeration<Object> params = pmParamModificar.keys();
            	while (params.hasMoreElements()) {
					String lsClave = (String) params.nextElement();
					if (lsLinea.trim().startsWith(lsClave +"=")) {
                        // Quitar los espacios de antes del = para asegurarnos que es la clave que estamos buscando
                        String lsResto = lsLinea.trim().substring(lsClave.length()).trim();

                        if (lsResto.startsWith("=")) {
                            // Es la clave que buscamos
                            lsLinea = lsClave + "=" + pmParamModificar.getProperty(lsClave);
                        }
            		}
            		// Escribir linea en fichero
				}
            	lsBuffer.append(lsLinea).append(LINE_SEPARATOR);
            	
            } // Fin while leer linea fichero

            // Guardar en fichero
            loOutFile = new FileOutputStream(psFichero);
            loOutFile.write(lsBuffer.toString().getBytes());
            loOutFile.flush();
            
        } catch (Throwable e) {
        	moLog.error("modificarFicheroConfig",e);
        } finally {
            // Cerrar Outpustream
            try {
                loOutFile.close();
            } catch (Throwable e) {
            	moLog.error("modificarFicheroConfig - Cerrar Outpustream",e);
            }
        }
    }
    
}
