/**
 * European Union Public License
 * Empresa desarrolladora: SANDETEL
 * Autor: Junta de Andalucia.
 * Fecha Liberacion en 2012.
 *
 * Este programa es software libre: usted tiene derecho a redistribuirlo
 * y/o modificarlo bajo los terminos de la Licencia EUPL European Public
 * License publicada por el organismo IDABC de la Comision Europea, en su
 * version 1.0. o posteriores.
 *
 * Este programa se distribuye de buena fe, pero SIN NINGUNA GARANTIA,
 * incluso sin las presuntas garantias implicitas de USABILIDAD o
 * ADECUACION A PROPOSITO CONCRETO. Para mas informacion consulte la
 * Licencia EUPL European Public License.
 *
 * Usted recibe una copia de la Licencia EUPL European Public License junto
 * con este programa, si por algun motivo no le es posible visualizarla,
 * puede consultarla en la siguiente URL:
 * http://ec.europa.eu/idabc/servlets/Doc?id=31099
 *
 * You should have received a copy of the EUPL European Public License
 * along with this program. If not, see
 * http://ec.europa.eu/idabc/servlets/Doc?id=31096
 *
 * Sie sollten eine Kopie der EUPL European Public License zusammen mit
 * diesem Programm. Wenn nicht, finden Sie da
 * http://ec.europa.eu/idabc/servlets/Doc?id=29919
 */
package es.juntadeandalucia.afirma.wsclient.eSignature;

import org.apache.axis.utils.XMLUtils;
import org.w3c.dom.Document;

import com.sun.identity.shared.debug.Debug;

import es.juntadeandalucia.afirma.wsclient.WebServicesAvailable;
import es.juntadeandalucia.afirma.wsclient.utils.UtilsWebService;
import es.juntadeandalucia.openam.afirmaauth.Afirma;
import es.juntadeandalucia.openam.afirmaauth.AuthFirmaException;
import es.juntadeandalucia.openam.afirmaauth.Constantes;

public class ValidarFirma implements WebServicesAvailable {
	private static Debug debug = Debug.getInstance(Afirma.MODULE_NAME);

	public String getValidatedCertificate(String signValue, String signFormat,
			String originalData) throws AuthFirmaException {

		debug.message("Validando Firma de Autenticación contra @Firma");
		String certificateValue = null;
		String result = exec(signValue, signFormat, originalData);

		if (!"".equals(result) || result != null) {
			debug.message("Petición web recibida!");
			certificateValue = UtilsWebService.getInstance()
					.getNodeValueFromDocument(result, "certificado");

			debug.message("Certificado devuelto por @firma -> "
					+ certificateValue);
		} else {
			throw new AuthFirmaException(Constantes.ERROR_AUTH_CERTIFICADOS,
					"Error al validar firma, el valor devuelto es nulo o vacío");
		}
		if ("".equals(certificateValue) || certificateValue == null) {
			throw new AuthFirmaException(
					Constantes.ERROR_AUTH_CERTIFICADOS,
					"Error al obtener certificado de la validación de firma, el valor devuelto es nulo o vacío");
		}
		return certificateValue;
	}

	private String exec(String signValue, String signFormat, String originalData)
			throws AuthFirmaException {

		// Lectura del documento original
		byte[] data = originalData.getBytes();

		// Preparaci�n de la petici�n al servicio Web de ValidarFirma
		debug.message(" Preparando la petición al servicio Web "
				+ signatureValidationWebServiceName + "...");
		Document eSignatureValidationRequest = null;
		eSignatureValidationRequest = UtilsWebService.getInstance()
				.prepareValidateSignatureRequest(signValue, signFormat, null,
						null, data);

		if (debug.messageEnabled()) {

			// Lanzamiento de la petici�n WS
			debug.message("Lanzando la petición... ->");
			debug.message(XMLUtils
					.DocumentToString(eSignatureValidationRequest));
		}
		String response = UtilsWebService.getInstance().launchRequest(
				signatureValidationWebServiceName, eSignatureValidationRequest);

		if (debug.messageEnabled()) {
			debug.message("respuesta obtenida");
			debug.message(response);
		}

		if (!UtilsWebService.getInstance().isCorrect(response)) {
			debug.error("Error en la verificación de la firma de autenticación ...");

			String causa = "";
			try {
				causa = UtilsWebService.getInstance().getNodeValueFromDocument(
						response, "detalle");
				debug.error("CAUSA -> - "+ causa);
			} catch (Throwable e) {
			}
			throw new AuthFirmaException(Constantes.CERTIFICADO_NO_VALIDO,
					"Error en la verificación de la firma de autenticación, CAUSA: "
							+ causa);
		}
		debug.message("La validación de la firma ha sido correcta");

		return response;
	}

}
