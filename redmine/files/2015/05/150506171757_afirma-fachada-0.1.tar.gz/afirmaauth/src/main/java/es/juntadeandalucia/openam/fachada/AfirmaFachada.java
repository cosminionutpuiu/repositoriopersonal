/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package es.juntadeandalucia.openam.fachada;

import com.iplanet.sso.SSOException;
import com.sun.identity.authentication.spi.AMLoginModule;
import com.sun.identity.authentication.spi.InvalidPasswordException;
import com.sun.identity.authentication.spi.RedirectCallback;
import com.sun.identity.authentication.spi.UserNamePasswordValidationException;
import com.sun.identity.authentication.util.ISAuthConstants;
import com.sun.identity.idm.AMIdentity;
import com.sun.identity.idm.AMIdentityRepository;
import com.sun.identity.idm.IdRepoException;
import com.sun.identity.idm.IdSearchResults;
import com.sun.identity.idm.IdType;
import com.sun.identity.shared.datastruct.CollectionHelper;
import com.sun.identity.shared.debug.Debug;
import es.juntadeandalucia.afirma.authentication.TicketClient;
import es.juntadeandalucia.afirma.authentication.TicketClientBuilder;
import es.juntadeandalucia.afirma.authentication.beans.CertificateInfo;
import es.juntadeandalucia.afirma.authentication.beans.xml.GenerateTicketResponse;
import es.juntadeandalucia.afirma.authentication.beans.xml.GetTicketValInfoResponse;
import es.juntadeandalucia.afirma.servlet.AutFachadaUtil;
import es.juntadeandalucia.openam.afirmaauth.AfirmaPrincipal;
import es.juntadeandalucia.openam.afirmaauth.AuthFirmaException;
import es.juntadeandalucia.openam.afirmaauth.Constantes;
import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;
import java.security.Principal;
import java.util.ArrayList;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.ResourceBundle;
import java.util.Set;
import javax.security.auth.Subject;
import javax.security.auth.callback.Callback;
import javax.security.auth.callback.NameCallback;
import javax.security.auth.callback.PasswordCallback;
import javax.security.auth.login.LoginException;
import javax.servlet.http.HttpServletRequest;
import org.apache.commons.lang.StringUtils;
import org.apache.xerces.impl.dv.util.Base64;

/**
 *
 * @author Kan
 */
public class AfirmaFachada extends AMLoginModule {

    // Constantes
    private static final String AUTHLEVEL = "sunAMAuthAfirmaFachadaAuthLevel";
    public static final String MODULE_NAME = "AfirmaFachada";
    public static final String BUNDLE_NAME = "amAuthAfirmaFachada";
    // Estados
    private final static String ENTRADA_POR_CERTIFICADO = "1";
    private final static int STATE_ENTRADA_PRINCIPAL = 1;
    private final static int STATE_CERT = 2;
    // Log
    private static Debug debug = Debug.getInstance(MODULE_NAME);

    private AfirmaPrincipal principal;
    private Map currentConfig = null;
    private Map sharedState = null;
    private ResourceBundle bundle;

    protected String validatedUserID;
    private String userName;
    private String userPassword;

    public AfirmaFachada() {
        debug.message("* AfirmaFachada.AfirmaFachada()");
    }

    @Override
    public void init(Subject subject, Map sharedState, Map options) {
        debug.message("* AfirmaFachada.init(...,...,...)");
        debug.message("Inicializando módulo autenticación User/Pass y @firma-fachada ");

        limpiarErrores();

        if (debug.messageEnabled()) { // DEBUG,

            debug.message("****Contenido de sharedState****");

            for (Iterator iterator = sharedState.keySet().iterator(); iterator
                    .hasNext();) {
                String object = (String) iterator.next();
                debug.message("key " + object + " valor="
                        + sharedState.get(object));
            }

            debug.message("****Contenido de options****");

            for (Iterator iterator = options.keySet().iterator(); iterator
                    .hasNext();) {
                Object object = iterator.next();
                debug.message("key " + object + " valor=" + options.get(object));

            }
        }

        this.sharedState = sharedState;
        this.currentConfig = options;

        bundle = amCache.getResBundle(BUNDLE_NAME, getLoginLocale());

        if (debug.messageEnabled()) { // DEBUG,

            debug.message("****Contenido de bundle amAuthAfirma.properties****");

            for (Iterator<String> iterator = bundle.keySet().iterator(); iterator
                    .hasNext();) {
                String object = iterator.next();
                debug.message("key " + object + " valor="
                        + bundle.getString(object));

            }
        }

        String authLevel = CollectionHelper.getMapAttr(options, AUTHLEVEL);
        if (authLevel != null) {
            try {
                setAuthLevel(Integer.parseInt(authLevel));
            } catch (Exception e) {
                debug.error("Unable to set auth level " + authLevel, e);
            }
        }
    }

    @Override
    public int process(Callback[] callbacks, int state) throws LoginException {
        debug.message("* AfirmaFachada.process(...," + state + ")");

        if (debug.messageEnabled()) { // DEBUG,

            debug.message("****Callbacks****");
            for (int i = 0; i < callbacks.length; i++) {
                debug.message("Callback " + i + ": " + callbacks[i].toString());
            }
        }
        debug.message("Procesando petición ");
        debug.message("Estado: " + state);
        // copia del identificador de logado para su recuperación en caso de error
        String identificadorEntrada = "";
        try {

            switch (state) {

                case STATE_ENTRADA_PRINCIPAL:
                    Callback[] idCallbacks = new Callback[2];
                    limpiarErrores();

                    String isLoginCert = super.getHttpServletRequest()
                            .getParameter("isLoginCert");

                    // Se analiza si el submit desde la pg de login, ha sido para
                    // entrar por certificado o para hacer login...
                    if (ENTRADA_POR_CERTIFICADO.equalsIgnoreCase(isLoginCert)) {
                        // Entrada certificado
                        debug.message("Se ha seleccionado Login con certificado, obteniendo el ticket para enviar a @firma");

                        String urlCharSet = "UTF-8";
                        String ticketId = "";
                        String comeBackURLEncoded = "";
                        String sessionId = super.getHttpServletRequest().getSession().getId();
                        TicketClient ticketClient = TicketClientBuilder.getTicketClient();
                        GenerateTicketResponse ticketResp = ticketClient.generateTicket(sessionId);
                        if ((StringUtils.isNotBlank(ticketResp.getCodigo())) && ("0".equalsIgnoreCase(ticketResp.getCodigo()))) {
                            debug.message("Obtenido ticket " + ticketResp.getIdTicket());
                            super.getHttpServletRequest().getSession().setAttribute("afirma_ticket_client_ticketId", ticketResp.getIdTicket());
                            super.getHttpServletRequest().getSession().setAttribute("afirma_ticket_client_appId", ticketClient.getConfiguration().getIdApp());

                            ticketId = URLEncoder.encode(ticketResp.getIdTicket(), urlCharSet);

                            HttpServletRequest request = getHttpServletRequest();
                            String urlRequest = getFullURL(request, urlCharSet);
                            String urlServlet = ticketClient.getConfiguration().getUrlServlet();
                            if (urlServlet.indexOf("?") > 0) {
                                urlServlet += "&";
                            } else {
                                urlServlet += "?";
                            }
                            urlServlet += "returnURL=" + URLEncoder.encode(urlRequest, urlCharSet);
                            comeBackURLEncoded = URLEncoder.encode(Base64.encode(urlServlet.getBytes(urlCharSet)), urlCharSet);

                            String llamadaServidor = "https://" + ticketClient.getConfiguration().getTicketHost() + "/authenticationFacade?action=validateCert" + "&ticketId=" + ticketId + "&appId=" + ticketClient.getConfiguration().getIdApp() + "&webSessionId=" + sessionId + "&comeBackURL=" + comeBackURLEncoded;

                            debug.message("Realizando llamada al servidor de autenticacion: " + llamadaServidor);

                            Callback[] callbacks1 = getCallback(2);
                            RedirectCallback rc = (RedirectCallback) callbacks1[0];
                            Map redirectdata = rc.getRedirectData();
                            debug.message("Old RedirectData : " + redirectdata);
                            Map newRedirectData = new HashMap();
                            if (redirectdata != null) {
                                for (Iterator nvp = redirectdata.entrySet().iterator();
                                        nvp.hasNext();) {
                                    Map.Entry me = (Map.Entry) nvp.next();
                                    String key = (String) me.getKey();
                                    String value = (String) me.getValue();
                                    String newValue = value;
                                    newRedirectData.put(key, newValue);
                                }
                            }
                            debug.message("Status parameter: " + rc.getStatusParameter());
                            debug.message("RedirectBackUrlCookieName: " + rc.getRedirectBackUrlCookieName());
                            RedirectCallback rcNew = new RedirectCallback(
                                    llamadaServidor,
                                    newRedirectData,
                                    "GET",
                                    rc.getStatusParameter(),
                                    rc.getRedirectBackUrlCookieName());

                            replaceCallback(2, 0, rcNew);
                            debug.message("Rediriguiendo hacia la página de autenticación con Certificado");
                            return STATE_CERT;
                        }
                        return STATE_ENTRADA_PRINCIPAL;
                    } else {
                        // Entrada por Usuario/Password
                        try {
                            debug.message("Se ha seleccionado Login con Usuario/Password");
                            // captura del user/password -> copia del código del
                            // módulo DataStore presente en OpenAM....

                            if (callbacks != null && callbacks.length == 0) {
                                userName = (String) sharedState.get(getUserKey());
                                userPassword = (String) sharedState
                                        .get(getPwdKey());
                                if (userName == null || userPassword == null) {
                                    return ISAuthConstants.LOGIN_START;
                                }
                                NameCallback nameCallback = new NameCallback(
                                        "dummy");
                                nameCallback.setName(userName);
                                idCallbacks[0] = nameCallback;
                                PasswordCallback passwordCallback = new PasswordCallback(
                                        "dummy", false);
                                passwordCallback.setPassword(userPassword
                                        .toCharArray());
                                idCallbacks[1] = passwordCallback;
                            } else {
                                idCallbacks = callbacks;
                                // callbacks is not null
                                userName = ((NameCallback) callbacks[0]).getName();
                                userPassword = String
                                        .valueOf(((PasswordCallback) callbacks[1])
                                                .getPassword());
                            }
                            // Comprobar si el username está vacío
                            if (userPassword == null
                                    || userPassword.trim().length() == 0) {
                                if (debug.messageEnabled()) {
                                    debug.message("DataStore.process: Password is null/empty");
                                }
                                generaMensajeErrorUsuario(Constantes.USUARIO_PASSWORD_INCORRECTO);
                                return STATE_ENTRADA_PRINCIPAL;

                            }

                            // store username password both in success and failure case
                            storeUsernamePasswd(userName, userPassword);
                            if (debug.messageEnabled()) {
                                debug.message("getRequestOrg() -> "
                                        + getRequestOrg());
                                debug.message("Buscando al usuario con identificador libre "
                                        + userName);
                            }
                            // Nota: El identificador de entrada es el introducido en el form
                            // en el callback se pasa el RDN/identificador del usuario dentro 
                            // del datastore
                            // Se guarda para despues recuperarlo en caso de error...

                            identificadorEntrada = ((NameCallback) idCallbacks[0])
                                    .getName();

                            // Pattern p = Pattern.compile("[^A-Za-z0-9.@_-~#]+");
                            validateUserName(identificadorEntrada, "^\\w+([\\.]?\\w+)*"); // TODO: configurar la expresión regular en un parámetro.
                            /*
                             if (!Pattern.matches("^\\w+([\\.]?\\w+)*", identificadorEntrada)){
                             debug.message(" identificador " + identificadorEntrada +" posee caracteres no válidos");
                             generaMensajeErrorUsuario(Constantes.USUARIO_PASSWORD_INCORRECTO);
                             return STATE_ENTRADA_PRINCIPAL;
                             }
                             */

                            AMIdentityRepository idrepo = getAMIdentityRepository(getRequestOrg());

                            // Fin captura user/passw
                            HashMap<String, String> atributosUserPass = new HashMap<String, String>();
                            atributosUserPass.put("IDENTIFICADOR", userName);

                            // Buscando al usuario en el datastore
                            AfirmaPrincipal usuarioP = getIDUserInDatastore(atributosUserPass);
                            // authenticatedUser = usuarioP.getUid();
                            if (debug.messageEnabled()) {
                                debug.message("Logando al usuario con Identificador "
                                        + usuarioP.getName());
                            }

                            ((NameCallback) idCallbacks[0]).setName(usuarioP
                                    .getName());

                            // autenticando al usuario en el datastore...
                            boolean success = idrepo.authenticate(idCallbacks);

                            if (success) {
                                // Autenticación correcta
                                validatedUserID = userName;
                                principal = usuarioP;
                                return ISAuthConstants.LOGIN_SUCCEED;
                            } else {
                                // Autenticación incorrecta
                                principal = null;
                                generaMensajeErrorUsuario(Constantes.USUARIO_PASSWORD_INCORRECTO);
                                ((NameCallback) idCallbacks[0])
                                        .setName(identificadorEntrada);
                                return STATE_ENTRADA_PRINCIPAL;
                            }

                        } catch (InvalidPasswordException ex) {
                            ((NameCallback) idCallbacks[0])
                                    .setName(identificadorEntrada);
                            debug.message("idRepo Exception", ex);
                            // setFailureID(userName);
                            generaMensajeErrorUsuario(Constantes.USUARIO_PASSWORD_INCORRECTO);
                            return STATE_ENTRADA_PRINCIPAL;
                        } catch (UserNamePasswordValidationException ex) {
                            ((NameCallback) idCallbacks[0])
                                    .setName(identificadorEntrada);
                            debug.message("idRepo Exception", ex);
                            // setFailureID(userName);
                            generaMensajeErrorUsuario(Constantes.USUARIO_PASSWORD_INCORRECTO);
                            return STATE_ENTRADA_PRINCIPAL;
                        }
                    }

                case STATE_CERT:
                    debug.message("Submit desde la página de login por certificado");
                    limpiarErrores();
                    HttpServletRequest request = getHttpServletRequest();

                    String descResultado = "";
                    boolean validezTicket = false;
                    GetTicketValInfoResponse ticketResp = null;
                    List datosCertficado = new ArrayList();
                    String codResultado = "";

                    String rErrorCode = request.getParameter("resCode");
                    String rTicketId = request.getParameter("ticketId");
                    String rAppId = request.getParameter("appId");
                    String rSessionId = request.getParameter("webSessionId");

                    String sTicketId = (String) request.getSession().getAttribute("afirma_ticket_client_ticketId");
                    String sAppId = (String) request.getSession().getAttribute("afirma_ticket_client_appId");

                    request.getSession().removeAttribute("afirma_ticket_client_ticketId");
                    request.getSession().removeAttribute("afirma_ticket_client_appId");

                    TicketClient ticketClient = TicketClientBuilder.getTicketClient();

                    if ("0".equalsIgnoreCase(rErrorCode)) {
                        if (request.getSession().getId().equals(rSessionId)) {
                            if ((StringUtils.isNotBlank(sTicketId)) && (StringUtils.isNotBlank(rTicketId)) && (sTicketId.equals(rTicketId))) {
                                if ((StringUtils.isNotBlank(sAppId)) && (StringUtils.isNotBlank(rAppId)) && (sAppId.equals(rAppId))) {
                                    ticketResp = ticketClient.getTicketValInfo(rTicketId, rSessionId);

                                    if ((StringUtils.isNotBlank(ticketResp.getCodigo())) && ("0".equalsIgnoreCase(ticketResp.getCodigo()))) {
                                        if ("0".equalsIgnoreCase(ticketResp.getEstadoValidacionCertificado())) {
                                            validezTicket = true;
                                            descResultado = ticketResp.getDescripcion();
                                            debug.message("Ticket y certificado correctos");
                                        } else {
                                            validezTicket = false;
                                            descResultado = ticketResp.getEstadoValidacionCertificado() + " - " + ticketResp.getDescripcionEstadoValidacionCertificado();

                                            debug.message("[ERROR] El certificado no ha pasado la validación");
                                        }
                                        datosCertficado = ticketResp.getCertificateInfoList();
                                    } else {
                                        codResultado = ticketResp.getCodigo();
                                        String errorDesc = ticketResp.getDescripcion();
                                        descResultado = "Error en la validación del ticket: codigo de error: " + codResultado + " - " + errorDesc;

                                        debug.message("[ERROR] " + descResultado);
                                    }

                                } else {
                                    descResultado = "El identificador de aplicacion no coincide con el retornado por el modulo de Autenticacion Web.";

                                    debug.message("[ERROR] " + descResultado);
                                }

                            } else {
                                descResultado = "El identificador de ticket no coincide con el retornado por el modulo de Autenticacion Web.";

                                debug.message("[ERROR] " + descResultado);
                            }

                        } else {
                            descResultado = "La sesion actual no coincide con la retornada por el modulo de Autenticacion Web.";
                            debug.message("[ERROR] " + descResultado);
                        }

                    } else {
                        descResultado = AutFachadaUtil.analisisErrorModulo(rErrorCode);
                        debug.message("[ERROR] " + "Error devuelto por el modulo de fachada de autenticacion: " + descResultado);
                    }

                    if (validezTicket) {
                        principal = procesarAutenticacionCertificado(datosCertficado);
                        return ISAuthConstants.LOGIN_SUCCEED;
                    } else {
                        generaMensajeErrorUsuario(Constantes.ERROR_AUTH_CERTIFICADOS);
                        return STATE_ENTRADA_PRINCIPAL;
                    }
                default: {
                    return STATE_ENTRADA_PRINCIPAL;
                }
            }
        } catch (AuthFirmaException e) {
            debug.error("AuthFirmaException capturada");
            debug.error(e.getMessage(), e);
            generaMensajeErrorUsuario(e);
            return STATE_ENTRADA_PRINCIPAL;
        } catch (Throwable t) {
            debug.error("Error - Stage:" + state + "]");
            debug.error(t.getMessage(), t);
            generaMensajeErrorUsuario(Constantes.ERROR_GENERICO);
            return STATE_ENTRADA_PRINCIPAL;

        }

    }

    private AfirmaPrincipal procesarAutenticacionCertificado(
            List datosCertficado) throws AuthFirmaException {

        debug.message("Iniciando validación autenticación @firma");

        HashMap<String, String> atributosCertificado = new HashMap<String, String>();
        Iterator iterator = datosCertficado.iterator();
        while (iterator.hasNext()) {
            CertificateInfo certificateInfo = (CertificateInfo) iterator.next();
            debug.message("* " + certificateInfo.getFieldIdentity() + ": " + certificateInfo.getFieldValue());
            atributosCertificado.put(certificateInfo.getFieldIdentity(), certificateInfo.getFieldValue());
        }
        debug.message("Buscando Identidad del Firmante en el Datastore");

        AfirmaPrincipal usuario = getIDUserInDatastore(atributosCertificado);
        debug.message("Usuario autenticado -> " + usuario.toString());

        if (usuario == null) {
            throw new AuthFirmaException(Constantes.USUARIO_NO_EN_SISTEMA,
                    "No se ha encontrado el usuario en el Sistema");
        }
        return usuario;
    }

    private String getFullURL(HttpServletRequest request, String urlCharSet) throws UnsupportedEncodingException {
        StringBuffer requestURL = request.getRequestURL();
        requestURL.append("?");
        Enumeration<String> params = request.getParameterNames();
        while (params.hasMoreElements()) {
            String name = params.nextElement();
            String value = "";
            if (request.getParameter(name) != null) {
                value = request.getParameter(name);
            }
            requestURL.append(name += "=" + URLEncoder.encode(value, urlCharSet));
            if (params.hasMoreElements()) {
                requestURL.append("&");
            }
        }
        return requestURL.toString();
    }

    private void limpiarErrores() {
        debug.message("Limpiando errores de sesion");
        super.getHttpServletRequest().getSession().removeAttribute("errorCode");
        super.getHttpServletRequest().getSession().removeAttribute("errorMSG");

    }

    private void limpiarSession() {
        debug.message("Limpiando datos sesion");
        super.getHttpServletRequest().getSession().removeAttribute("errorCode");
        super.getHttpServletRequest().getSession().removeAttribute("errorMSG");
        super.getHttpServletRequest().getSession().removeAttribute("goto");
        super.getHttpServletRequest().getSession()
                .removeAttribute("gotoOnFail");
        super.getHttpServletRequest().getSession()
                .removeAttribute("SunQueryParamsString");
        super.getHttpServletRequest().getSession().removeAttribute("encoded");

    }

    private void generaMensajeErrorUsuario(AuthFirmaException exception) {

        generaMensajeErrorUsuario(exception.getCodigo());
    }

    private void generaMensajeErrorUsuario(String codError) {

        String msg = "";
        try {
            msg = bundle.getString(codError);
        } catch (Throwable e) {
            debug.error(
                    "Error: el codigo de error "
                    + codError
                    + " no se encuentra definido en el fichero de propiedades ",
                    e);
            msg = bundle.getString(Constantes.ERROR_GENERICO);
        }

        debug.message("Generando error, codigo=" + codError + " msg=" + msg);
        super.getHttpServletRequest().getSession()
                .setAttribute("errorCode", codError);
        super.getHttpServletRequest().getSession()
                .setAttribute("errorMSG", msg);
        super.getHttpServletRequest()
                .getSession()
                .setAttribute("goto",
                        super.getHttpServletRequest().getParameter("goto"));
        super.getHttpServletRequest()
                .getSession()
                .setAttribute(
                        "gotoOnFail",
                        super.getHttpServletRequest()
                        .getParameter("gotoOnFail"));
        super.getHttpServletRequest()
                .getSession()
                .setAttribute(
                        "SunQueryParamsString",
                        super.getHttpServletRequest().getParameter(
                                "SunQueryParamsString"));
        super.getHttpServletRequest()
                .getSession()
                .setAttribute("encoded",
                        super.getHttpServletRequest().getParameter("encoded"));
    }

    @Override
    public Principal getPrincipal() {
        debug.message("* AfirmaFachada.getPrincipal()");
        debug.message("Pidiendo el principal ");

        if (principal != null) {
            debug.message("Pidiendo el principal " + principal);
            return (Principal) principal.clone();

        }
        return null;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public void destroyModuleState() {
        debug.message("destroyModuleState ()");
        principal = null;
        limpiarSession();
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public void nullifyUsedVars() {
        debug.message("nullifyUsedVars() ");
        currentConfig = null;
        sharedState = null;
        limpiarSession();
    }

    private AfirmaPrincipal getIDUserInDatastore(
            HashMap<String, String> atributosCertificado)
            throws AuthFirmaException {
        AfirmaPrincipal usuario = null;
        try {

            String nif = atributosCertificado.get("NIFResponsable");
            String libre = atributosCertificado.get("IDENTIFICADOR");

            usuario = new AfirmaPrincipal();
            debug.message(" atributos ->  " + atributosCertificado);
            AMIdentityRepository idrepo = getAMIdentityRepository(getRequestOrg());

            // Inicializando campos de búsqueda en el datastore..
            Map valores = new HashMap<String, String>(); // campos de búsqueda
            // para la consulta
            // en el datastore

            if (nif != null && !nif.trim().equals("")) { // Viene de
                // autenticación por
                // certificados
                debug.message("Preparando búsqueda para login con certificado");

                nif = nif.trim();

                // verificando que el identificador no esté en la lista de
                // bloqueados.
                if (this.currentConfig
                        .get(Constantes.AFIRMA_FACHADA_SERVICE_CAMPOS_NIFS_BLOQUEADOS) != null) {
                    Set nifBloqueados = (Set) this.currentConfig
                            .get(Constantes.AFIRMA_FACHADA_SERVICE_CAMPOS_NIFS_BLOQUEADOS);
                    if (nifBloqueados.contains(nif.toLowerCase())
                            || nifBloqueados.contains(nif.toUpperCase())) {
                        debug.message("El nif "
                                + nif
                                + " está en la lista de NIFs bloqueados en el SSOWeb");
                        throw new AuthFirmaException(
                                Constantes.IDENTIFICADOR_BLOQUEADO,
                                "Su NIF está bloqueado en el SSOWeb");

                    }
                } else {
                    debug.message("No se ha encontrado una lista de NIFs bloqueados en la configuración");
                }

                String campoNifDatastore = (String) ((Set) this.currentConfig
                        .get(Constantes.AFIRMA_FACHADA_SERVICE_CAMPOS_NIF_DATASTORE))
                        .iterator().next();
                debug.message("Se busca al usuario por el campo "
                        + campoNifDatastore + " del datastore");
                HashSet temp = new HashSet(2);
                temp.add(nif.toLowerCase());
                temp.add(nif.toUpperCase());
                valores.put(campoNifDatastore, temp);
            } else if (libre != null && !libre.trim().equals("")) { // autenticación
                // por
                // user/passw
                debug.message("Preparando búsqueda para login con Usuario/Password");

                libre = libre.trim();

                // verificando que el identificador no esté en la lista de
                // bloqueados.
                Set nifBloqueados = (Set) this.currentConfig
                        .get(Constantes.AFIRMA_FACHADA_SERVICE_CAMPOS_NIFS_BLOQUEADOS);
                if (nifBloqueados.contains(libre.toLowerCase())
                        || nifBloqueados.contains(libre.toUpperCase())) {
                    debug.message("El identificador "
                            + libre
                            + " está en la lista de identificadores Bloqueados por el SSOWeb");
                    throw new AuthFirmaException(
                            Constantes.IDENTIFICADOR_BLOQUEADO,
                            "Su identificador está bloqueado en el SSOWeb");

                }

                Set campos = (Set) this.currentConfig
                        .get(Constantes.AFIRMA_FACHADA_SERVICE_CAMPOS_LOGIN_DATASTORE);

                debug.message("CAMPOS -> " + campos);

                // Añadiendo los campos identificadores configurados
                if (campos != null && campos.size() > 0) {
                    for (Iterator iterator = campos.iterator(); iterator
                            .hasNext();) {
                        String campo = (String) iterator.next();
                        debug.message("Se busca al usuario por el campo "
                                + campo);
                        HashSet a = new HashSet(3); // por si el datastore es
                        // sensible a mayúsculas.
                        a.add(libre);
                        a.add(libre.toLowerCase());
                        a.add(libre.toUpperCase());
                        valores.put(campo, a);
                    }
                } else {
                    debug.message("No se han configurado campos, añadiento campos uid y cn por defecto.");
                    HashSet temp = new HashSet(3);
                    temp.add(libre);
                    temp.add(libre.toLowerCase());
                    temp.add(libre.toUpperCase());
                    valores.put("uid", temp);
                    valores.put("cn", temp);
                }

            }

            // atributos devueltos por la consulta... No se usan ya que se
            // solicita devolver todos los atributos
            Set atributosDevueltos = new HashSet<String>();
            atributosDevueltos.add("uid");
            atributosDevueltos.add("cn");
            atributosDevueltos.add("dn");

            IdSearchResults result = idrepo.searchIdentities(IdType.USER, "*",
                    valores, true, 2, 6000, atributosDevueltos, true);

            Set resultados = result.getSearchResults();

            if (resultados.isEmpty()) {

                debug.message("No se ha encontrador la identidad en el datastore.....");

                throw new AuthFirmaException(
                        Constantes.USUARIO_PASSWORD_INCORRECTO,
                        "El usuario no existe en el sistema");

            }

            if (resultados.size() == 1) {

                debug.message("Se ha encontrado la identidad en el datastore.....");

                Map atributosIdentidad = ((AMIdentity) resultados.iterator()
                        .next()).getAttributes();

                // DEBUG Atributos
                Set claves = atributosIdentidad.keySet();

                if (debug.messageEnabled()) {
                    debug.message("Pintando atributos de la identidad recuperada del datastore.");
                    String as = "";
                    for (Iterator it2 = claves.iterator(); it2.hasNext();) {
                        as = (String) it2.next();
                        debug.message("\t CLAVE " + as + " valor= "
                                + atributosIdentidad.get(as));

                    }
                }

                // FIN DEBUG Atributos
                // SetName se pone el campo de logín único dentro del
                // datastore...
                // TODO: hacerlo bien -> poner en la configuración atributos
                // para definir estos campos en el datastore, esto para otra
                // versión.
                try {
                    usuario.setName(((Set<String>) atributosIdentidad.get((String) ((Set) this.currentConfig
                            .get(Constantes.AFIRMA_FACHADA_SERVICE_CAMPO_RDN_DATASTORE))
                            .iterator().next())).iterator().next());
                } catch (Throwable e) {
                }

                try {
                    usuario.setNombre(((Set<String>) atributosIdentidad
                            .get("givenname")).iterator().next());
                } catch (Throwable e) {
                }
                try {
                    usuario.setApellido1(((Set<String>) atributosIdentidad
                            .get("sn")).iterator().next());
                } catch (Throwable e) {
                }

                try {
                    usuario.setApellido2(((Set<String>) atributosIdentidad
                            .get("sn2")).iterator().next());
                } catch (Throwable e) {
                }

                try {
                    usuario.setNif(((Set<String>) atributosIdentidad.get((String) ((Set) this.currentConfig
                            .get(Constantes.AFIRMA_FACHADA_SERVICE_CAMPOS_NIF_DATASTORE))
                            .iterator().next())).iterator().next());
                } catch (Throwable e) {
                }

                try {
                    usuario.setAnagrama(((Set<String>) atributosIdentidad
                            .get("anagramafiscal")).iterator().next());
                } catch (Throwable e) {
                }

                try {
                    usuario.setMail(((Set<String>) atributosIdentidad
                            .get("mail")).iterator().next());
                } catch (Throwable e) {
                }

                try {
                    usuario.setUid(((Set<String>) atributosIdentidad.get("uid"))
                            .iterator().next());
                    debug.message("\t UID de la identidad logada"
                            + atributosIdentidad.get("uid"));

                    // authenticatedUser = (String)
                    // atributosIdentidad.get("uid");
                } catch (Throwable e) {
                }

                return usuario;

            } else {
                debug.message("Se han encontrado varias cuentas asociadas a la Credencial Introducida, seleccione otro mecanismo de autenticación.....");

                Iterator<AMIdentity> it = resultados.iterator();
                while (it.hasNext()) {
                    debug.message("* Identidad encontrada *");
                    Map atributosIdentidad = it.next().getAttributes();

                    // DEBUG Atributos
                    Set claves = atributosIdentidad.keySet();

                    if (debug.messageEnabled()) {
                        debug.message("Pintando atributos de la identidad recuperada del datastore.");
                        String as = "";
                        for (Iterator it2 = claves.iterator(); it2.hasNext();) {
                            as = (String) it2.next();
                            debug.message("\t CLAVE " + as + " valor= "
                                    + atributosIdentidad.get(as));

                        }
                    }
                }

                throw new AuthFirmaException(
                        Constantes.IDENTIFICADOR_DUPLICADO,
                        "Se han encontrado varias cuentas asociadas a la Credencial Introducida, seleccione otro mecanismo de autenticación más restrictivo como el identificador de Correo");

            }
        } catch (SSOException e) {
            e.printStackTrace();
            throw new AuthFirmaException(Constantes.ERROR_GENERICO, e);
        } catch (IdRepoException e) {
            e.printStackTrace();
            throw new AuthFirmaException(Constantes.ERROR_GENERICO, e);
        }

    }
}
