/**
 * European Union Public License
 * Empresa desarrolladora: SANDETEL
 * Autor: Junta de Andalucia.
 * Fecha Liberacion en 2012.
 *
 * Este programa es software libre: usted tiene derecho a redistribuirlo
 * y/o modificarlo bajo los terminos de la Licencia EUPL European Public
 * License publicada por el organismo IDABC de la Comision Europea, en su
 * version 1.0. o posteriores.
 *
 * Este programa se distribuye de buena fe, pero SIN NINGUNA GARANTIA,
 * incluso sin las presuntas garantias implicitas de USABILIDAD o
 * ADECUACION A PROPOSITO CONCRETO. Para mas informacion consulte la
 * Licencia EUPL European Public License.
 *
 * Usted recibe una copia de la Licencia EUPL European Public License junto
 * con este programa, si por algun motivo no le es posible visualizarla,
 * puede consultarla en la siguiente URL:
 * http://ec.europa.eu/idabc/servlets/Doc?id=31099
 *
 * You should have received a copy of the EUPL European Public License
 * along with this program. If not, see
 * http://ec.europa.eu/idabc/servlets/Doc?id=31096
 *
 * Sie sollten eine Kopie der EUPL European Public License zusammen mit
 * diesem Programm. Wenn nicht, finden Sie da
 * http://ec.europa.eu/idabc/servlets/Doc?id=29919
 */

package es.juntadeandalucia.openam.afirmaauth;

import java.security.Principal;

public class AfirmaPrincipal implements Principal, Cloneable {

	private String name;
	private String nif, nombre, apellido1, apellido2, anagrama, uid,mail;

	public String getUid() {
		return uid;
	}

	public void setUid(String uid) {
		this.uid = uid;
	}

	public String getMail() {
		return mail;
	}

	public void setMail(String mail) {
		this.mail = mail;
	}

	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public String getApellido1() {
		return apellido1;
	}

	public void setApellido1(String apellido1) {
		this.apellido1 = apellido1;
	}

	public String getApellido2() {
		return apellido2;
	}

	public void setApellido2(String apellido2) {
		this.apellido2 = apellido2;
	}

	public void setName(String name) {
		this.name = name;
	}

	public AfirmaPrincipal() {

	}

	public AfirmaPrincipal(String name) {
		this.name = name;
	}

	@Override
	public String getName() {
		return name;
	}

	@Override
	public boolean equals(Object obj) {
		if (obj == null) {
			return false;
		}
		if (getClass() != obj.getClass()) {
			return false;
		}
		final AfirmaPrincipal other = (AfirmaPrincipal) obj;
		if ((this.name == null) ? (other.name != null) : !this.name
				.equals(other.name)) {
			return false;
		}
		return true;
	}

	@Override
	public int hashCode() {
		int hash = 7;
		hash = 79 * hash + (this.name != null ? this.name.hashCode() : 0);
		return hash;
	}

	@Override
	public String toString() {

		return new StringBuffer("UID=").append(getUid()).
				append(" Nombre=").append(getNombre()).append(" Apellido1=")
				.append(getApellido1()).append(" Apellido2=")
				.append(getApellido2()).append(" NIF=").append(getNif())
				.append(" mail=").append(getMail())
				.append(" Anagrama=").append(getAnagrama())
				.append(" PRINCIPAL_NAME=").append(getName())
				.toString();

	}

    public Object clone(){
        Object obj=null;
        try{
            obj=super.clone();
        }catch(CloneNotSupportedException ex){
            System.out.println(" no se puede duplicar");
        }
        return obj;
    }

	
	public String getNif() {
		return nif;
	}

	public void setNif(String nif) {
		this.nif = nif;
	}

	public String getAnagrama() {
		return anagrama;
	}

	public void setAnagrama(String anagrama) {
		this.anagrama = anagrama;
	}
}
