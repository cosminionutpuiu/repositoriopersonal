/**
 * European Union Public License
 * Empresa desarrolladora: SANDETEL
 * Autor: Junta de Andalucia.
 * Fecha Liberacion en 2012.
 *
 * Este programa es software libre: usted tiene derecho a redistribuirlo
 * y/o modificarlo bajo los terminos de la Licencia EUPL European Public
 * License publicada por el organismo IDABC de la Comision Europea, en su
 * version 1.0. o posteriores.
 *
 * Este programa se distribuye de buena fe, pero SIN NINGUNA GARANTIA,
 * incluso sin las presuntas garantias implicitas de USABILIDAD o
 * ADECUACION A PROPOSITO CONCRETO. Para mas informacion consulte la
 * Licencia EUPL European Public License.
 *
 * Usted recibe una copia de la Licencia EUPL European Public License junto
 * con este programa, si por algun motivo no le es posible visualizarla,
 * puede consultarla en la siguiente URL:
 * http://ec.europa.eu/idabc/servlets/Doc?id=31099
 *
 * You should have received a copy of the EUPL European Public License
 * along with this program. If not, see
 * http://ec.europa.eu/idabc/servlets/Doc?id=31096
 *
 * Sie sollten eine Kopie der EUPL European Public License zusammen mit
 * diesem Programm. Wenn nicht, finden Sie da
 * http://ec.europa.eu/idabc/servlets/Doc?id=29919
 */

package es.juntadeandalucia.openam.afirmaauth;

import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.iplanet.sso.SSOException;
import com.iplanet.sso.SSOToken;
import com.sun.identity.authentication.spi.AMPostAuthProcessInterface;
import com.sun.identity.authentication.spi.AuthenticationException;
import com.sun.identity.idm.AMIdentity;
import com.sun.identity.idm.IdRepoException;
import com.sun.identity.idm.IdUtils;
import com.sun.identity.shared.debug.Debug;

@SuppressWarnings({ "unchecked", "rawtypes" })
public class AfirmaPostAuthenticationProcessing implements
		AMPostAuthProcessInterface {

	private static Debug debug = Debug
			.getInstance("PostAuthenticationProcessing");

	@Override
	public void onLoginSuccess(Map requestMap, HttpServletRequest request,
			HttpServletResponse response, SSOToken ssoToken)
			throws AuthenticationException {

		System.out
				.println("*********************** PostAuthenticationProcessing#onLogin started");
		debug.message("PostAuthenticationProcessing#onLogin started");
		try {
			// get the identity for profileattribute checking
			AMIdentity identity = IdUtils.getIdentity(ssoToken);
			// set a session property based on previous logic
			ssoToken.setProperty("my.own.session.property", "value");
		} catch (IdRepoException ire) {
			debug.warning("IdRepoException occured during getIdentity", ire);
		} catch (SSOException ssoe) {
			debug.warning("SSOException occured during getIdentity", ssoe);
		}
	}

	@Override
	public void onLoginFailure(Map requestMap, HttpServletRequest request,
			HttpServletResponse response) throws AuthenticationException {
	}

	@Override
	public void onLogout(HttpServletRequest request,
			HttpServletResponse response, SSOToken ssoToken)
			throws AuthenticationException {
	}
}
