/**
 * European Union Public License
 * Empresa desarrolladora: SANDETEL
 * Autor: Junta de Andalucia.
 * Fecha Liberacion en 2012.
 *
 * Este programa es software libre: usted tiene derecho a redistribuirlo
 * y/o modificarlo bajo los terminos de la Licencia EUPL European Public
 * License publicada por el organismo IDABC de la Comision Europea, en su
 * version 1.0. o posteriores.
 *
 * Este programa se distribuye de buena fe, pero SIN NINGUNA GARANTIA,
 * incluso sin las presuntas garantias implicitas de USABILIDAD o
 * ADECUACION A PROPOSITO CONCRETO. Para mas informacion consulte la
 * Licencia EUPL European Public License.
 *
 * Usted recibe una copia de la Licencia EUPL European Public License junto
 * con este programa, si por algun motivo no le es posible visualizarla,
 * puede consultarla en la siguiente URL:
 * http://ec.europa.eu/idabc/servlets/Doc?id=31099
 *
 * You should have received a copy of the EUPL European Public License
 * along with this program. If not, see
 * http://ec.europa.eu/idabc/servlets/Doc?id=31096
 *
 * Sie sollten eine Kopie der EUPL European Public License zusammen mit
 * diesem Programm. Wenn nicht, finden Sie da
 * http://ec.europa.eu/idabc/servlets/Doc?id=29919
 */
package es.juntadeandalucia.afirma.wsclient.utils;

import es.juntadeandalucia.openam.afirmaauth.AuthFirmaException;
import es.juntadeandalucia.openam.afirmaauth.Constantes;

public class UtilsCertificate
{
	public static final String CERTIFICATE_HEAD_BASE64= "-----BEGIN CERTIFICATE-----";
	
	public static final String CERTIFICATE_END_BASE64= "-----END CERTIFICATE-----";
	
	/**
	 * M�todo que elimina el patr�n de comienzo y fin en un certificado codificado en Base64
	 * 
	 * @param data Certificado codificado en Base64
	 * @return Certificado con los patrones del comienzo y fin eliminados
	 * @throws AuthFirmaException 
	 * @throws NullPointerException 
	 */
	public static byte[] deletePatternCertificateBase64Encoded(byte[] certificate) throws AuthFirmaException 
	{
		String sCertificate = null;
		boolean flag = false;
		
		if (certificate == null)
			throw new AuthFirmaException(Constantes.ERROR_AUTH_CERTIFICADOS, "Error en el certificado a validar, es nulo");
		
		
		sCertificate = new String(certificate).trim();
		
		if (sCertificate.startsWith(CERTIFICATE_HEAD_BASE64))
		{
			sCertificate=sCertificate.replaceAll(CERTIFICATE_HEAD_BASE64," ");
			System.out.println("  > Borrado el patron del certificado " + CERTIFICATE_HEAD_BASE64);
			flag = true;
		}
		if (sCertificate.endsWith(CERTIFICATE_END_BASE64)){
			sCertificate=sCertificate.replaceAll(CERTIFICATE_END_BASE64," ");
			System.out.println("  > Borrado el patron del certificado " + CERTIFICATE_END_BASE64);
			flag = true;
		}
				
		if (flag)
			return sCertificate.trim().getBytes();
		else
			return certificate;
	}
	
}
