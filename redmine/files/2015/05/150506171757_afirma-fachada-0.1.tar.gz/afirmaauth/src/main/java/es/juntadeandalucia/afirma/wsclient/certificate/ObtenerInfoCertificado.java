/**
 * European Union Public License
 * Empresa desarrolladora: SANDETEL
 * Autor: Junta de Andalucia.
 * Fecha Liberacion en 2012.
 *
 * Este programa es software libre: usted tiene derecho a redistribuirlo
 * y/o modificarlo bajo los terminos de la Licencia EUPL European Public
 * License publicada por el organismo IDABC de la Comision Europea, en su
 * version 1.0. o posteriores.
 *
 * Este programa se distribuye de buena fe, pero SIN NINGUNA GARANTIA,
 * incluso sin las presuntas garantias implicitas de USABILIDAD o
 * ADECUACION A PROPOSITO CONCRETO. Para mas informacion consulte la
 * Licencia EUPL European Public License.
 *
 * Usted recibe una copia de la Licencia EUPL European Public License junto
 * con este programa, si por algun motivo no le es posible visualizarla,
 * puede consultarla en la siguiente URL:
 * http://ec.europa.eu/idabc/servlets/Doc?id=31099
 *
 * You should have received a copy of the EUPL European Public License
 * along with this program. If not, see
 * http://ec.europa.eu/idabc/servlets/Doc?id=31096
 *
 * Sie sollten eine Kopie der EUPL European Public License zusammen mit
 * diesem Programm. Wenn nicht, finden Sie da
 * http://ec.europa.eu/idabc/servlets/Doc?id=29919
 */
package es.juntadeandalucia.afirma.wsclient.certificate;

import java.util.HashMap;

import org.apache.axis.utils.XMLUtils;
import org.w3c.dom.Document;

import com.sun.identity.shared.debug.Debug;

import es.juntadeandalucia.afirma.wsclient.WebServicesAvailable;
import es.juntadeandalucia.afirma.wsclient.utils.UtilsCertificate;
import es.juntadeandalucia.afirma.wsclient.utils.UtilsWebService;
import es.juntadeandalucia.openam.afirmaauth.Afirma;
import es.juntadeandalucia.openam.afirmaauth.AuthFirmaException;
import es.juntadeandalucia.openam.afirmaauth.Constantes;

public class ObtenerInfoCertificado implements WebServicesAvailable {

	private static Debug debug = Debug.getInstance(Afirma.MODULE_NAME);

	/**
	 * 
	 * @param appId
	 *            Nombre de la ID de aplicación del WSDL
	 * @param certificateBase64data
	 *            Certificado en base64
	 * @return
	 * @throws Exception
	 */
	public HashMap<String, String> getInfoNodeFromCertificate(
			String certificateBase64data) throws AuthFirmaException {
		String certificateValues = null;
		debug.message("Obteniendo datos del certificado");
		String certificateResponse = exec(certificateBase64data);

		if (!"".equals(certificateResponse) || certificateResponse != null) {
			certificateValues = UtilsWebService.getInstance()
					.getXMLChildsFromDocumentNode(certificateResponse,
							"ResultadoProcesamiento");

			if ("".equals(certificateValues) || certificateValues == null) {
				debug.error("El certificado recibido no contiene el nodo ResultadoProcesamiento");
				throw new AuthFirmaException(
						Constantes.ERROR_AUTH_CERTIFICADOS,
						"El certificado recibido no contiene el nodo ResultadoProcesamiento");
			}
		} else {
			debug.error("La validación del Certificado obtenida desde @Firma es nula o vacía");
			new AuthFirmaException(Constantes.ERROR_AUTH_CERTIFICADOS,
					"La validación del Certificado obtenida desde @Firma es nula o vac�a");
		}

		HashMap<String, String> certificateValuesParsed = UtilsWebService
				.getInstance().getCertificateInfoParsed(certificateValues);

		if (certificateValuesParsed == null
				|| certificateValuesParsed.size() == 0) {
			debug.message("Ha habido un error parseando los valores del certificado obtenido.");
			new AuthFirmaException(Constantes.ERROR_AUTH_CERTIFICADOS,
					"Ha habido un error parseando los valores del certificado obtenido.");
		}

		return certificateValuesParsed;
	}

	public String exec(String certificateBase64data) throws AuthFirmaException {

		if (debug.messageEnabled()) {
			debug.message("Obteniendo datos del certificado "
					+ certificateBase64data + "...]");
		}
		byte[] certificateContentToGetInfo = certificateBase64data.getBytes();

		debug.message("..[Comprobando la codificación del certificado...]");

		certificateContentToGetInfo = UtilsCertificate
				.deletePatternCertificateBase64Encoded(certificateContentToGetInfo);
		try {
			if (!base64Coder.isBase64Encoded(certificateContentToGetInfo)) {
				debug.message(" > El certificado no se encuentra en Base 64. Codificando...");
				certificateContentToGetInfo = base64Coder
						.encodeBase64(certificateContentToGetInfo);
			}
		} catch (Exception e) {

			throw new AuthFirmaException(Constantes.ERROR_AUTH_CERTIFICADOS,
					"Error en el certificado a validar, es nulo", e);

		}

		debug.message("Codificación del certificado correcta...]");

		// Preparaci�n de la petici�n al servicio Web de
		// getCertificateInfoWebServiceName
		debug.message(".[Preparando la petición al servicio Web "
				+ getCertificateInfoWebServiceName + "...]");
		Document getCertificateInfoRequest = UtilsWebService.getInstance()
				.prepareGetCertificateInfoRequest(
						new String(certificateContentToGetInfo));
		debug.message(".[/Petición correctamente preparada]");

		if (debug.messageEnabled()) {
			// Lanzamiento de la petici�n WS
			debug.message(".[Lanzando la petición...]");
			debug.message("..[peticion]");
			debug.message(XMLUtils.DocumentToString(getCertificateInfoRequest));
			debug.message("..[/peticion]");
		}
		String response = UtilsWebService.getInstance().launchRequest(
				getCertificateInfoWebServiceName, getCertificateInfoRequest);

		if (debug.messageEnabled()) {
			debug.message("..[respuesta]");
			debug.message(response);
			debug.message("..[/respuesta]");
		}

		if (!UtilsWebService.getInstance().isCorrectGetCertificateInfoRequest(
				response)) {
			debug.error("Error en la petición de Obtención de Información del certificado ...");

			String causa = "";
			try {
				causa = UtilsWebService.getInstance().getNodeValueFromDocument(
						response, "detalle");
				debug.error("CAUSA -> - " + causa);
			} catch (Throwable e) {
			}
			throw new AuthFirmaException(Constantes.ERROR_AUTH_CERTIFICADOS,
					"Error al Obtener los datos del certificado, CAUSA: "
							+ causa);

		}
		debug.message("Petición realizada correctamente");

		return response;
	}

}
