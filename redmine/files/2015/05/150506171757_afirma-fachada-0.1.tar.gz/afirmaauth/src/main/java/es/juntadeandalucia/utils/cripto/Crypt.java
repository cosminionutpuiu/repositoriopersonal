/**
 * European Union Public License
 * Empresa desarrolladora: SANDETEL
 * Autor: Junta de Andalucia.
 * Fecha Liberacion en 2012.
 *
 * Este programa es software libre: usted tiene derecho a redistribuirlo
 * y/o modificarlo bajo los terminos de la Licencia EUPL European Public
 * License publicada por el organismo IDABC de la Comision Europea, en su
 * version 1.0. o posteriores.
 *
 * Este programa se distribuye de buena fe, pero SIN NINGUNA GARANTIA,
 * incluso sin las presuntas garantias implicitas de USABILIDAD o
 * ADECUACION A PROPOSITO CONCRETO. Para mas informacion consulte la
 * Licencia EUPL European Public License.
 *
 * Usted recibe una copia de la Licencia EUPL European Public License junto
 * con este programa, si por algun motivo no le es posible visualizarla,
 * puede consultarla en la siguiente URL:
 * http://ec.europa.eu/idabc/servlets/Doc?id=31099
 *
 * You should have received a copy of the EUPL European Public License
 * along with this program. If not, see
 * http://ec.europa.eu/idabc/servlets/Doc?id=31096
 *
 * Sie sollten eine Kopie der EUPL European Public License zusammen mit
 * diesem Programm. Wenn nicht, finden Sie da
 * http://ec.europa.eu/idabc/servlets/Doc?id=29919
 */
package es.juntadeandalucia.utils.cripto;

import java.io.UnsupportedEncodingException;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

import javax.crypto.Cipher;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;

import org.apache.commons.codec.binary.Base64;


public class Crypt {
    protected final String ALGORITHM = "DES/CBC/PKCS5Padding";
    protected final String CIPHER_ALG = "DES";
    protected final int lenBloq = 8;
    private byte[] bKey;
    private IvParameterSpec oIv;

    public Crypt(byte[] abyte0) throws Exception {
        bKey = "0".getBytes();
        oIv = null;

        try {
            bKey = abyte0;

            byte[] abyte1 = new byte[8];

            for (int i = 0; i < 8; i++)
                abyte1[i] = 0;

            oIv = new IvParameterSpec(abyte1);
        } catch (Exception exception) {
            throw exception;
        }
    }

    public byte[] cifradoDatos(byte[] abyte0) throws Exception {
        Object obj = null;
        Object obj2 = null;
        Object obj4 = null;
        byte[] abyte2 = null;
        Object obj6 = null;

        try {
            Cipher cipher = Cipher.getInstance("DES/CBC/PKCS5Padding");
            DESKeySpec deskeyspec = new DESKeySpec(bKey);
            SecretKeySpec secretkeyspec = new SecretKeySpec(deskeyspec.getKey(),
                    "DES");
            int i = abyte0.length % 8;
            i = 8 - i;

            byte[] abyte3 = new byte[abyte0.length + i];
            abyte3[(abyte0.length + i) - 1] = (byte) i;

            for (int j = 0; j < abyte0.length; j++)
                abyte3[j] = abyte0[j];

            cipher.init(1, secretkeyspec, oIv);

            abyte2 = cipher.doFinal(abyte3);
        } catch (Exception exception) {
            exception.printStackTrace();
            throw exception;
        } finally {
            Object obj1 = null;
            Object obj3 = null;
            Object obj5 = null;
            Object obj7 = null;
        }

        return abyte2;
    }

    public byte[] descifradoDatos(byte[] abyte0) throws Exception {
        Object obj = null;
        Object obj2 = null;
        Object obj4 = null;
        Object obj6 = null;
        Object obj8 = null;
        byte[] abyte3 = null;

        try {
            Cipher cipher = Cipher.getInstance("DES/CBC/PKCS5Padding");
            DESKeySpec deskeyspec = new DESKeySpec(bKey);
            SecretKeySpec secretkeyspec = new SecretKeySpec(deskeyspec.getKey(),
                    "DES");
            byte[] abyte2 = abyte0;
            cipher.init(2, secretkeyspec, oIv);

            byte[] abyte1 = cipher.doFinal(abyte2);
            int i = abyte1.length - abyte1[abyte1.length - 1];
            abyte3 = new byte[i];

            for (int j = 0; j < i; j++)
                abyte3[j] = abyte1[j];
        } catch (Exception exception) {
            throw exception;
        } finally {
            Object obj1 = null;
            Object obj3 = null;
            Object obj5 = null;
            Object obj7 = null;
            Object obj9 = null;
        }

        return abyte3;
    }
    
    private static final byte[] CLAVE_DES = {(byte)0x67, (byte)0x17, (byte)0x031, (byte)0xC2, (byte)0xAE, (byte)0x91, (byte)0xA7, (byte)0x0E,
		(byte)0x92, (byte)0x23, (byte)0x321, (byte)0xf5, (byte)0xBC, (byte)0x43, (byte)0x67, (byte)0x4C,
		(byte)0x46, (byte)0x76, (byte)0x453, (byte)0xD2, (byte)0xAE, (byte)0x54, (byte)0xD7, (byte)0x5F,
		(byte)0x78, (byte)0x78, (byte)0x546, (byte)0xA6, (byte)0xAC, (byte)0x16, (byte)0xC8, (byte)0x6A
    };
    
	/**
	 * Realiza el cifrado simetrico
	 * 
	 * @param datos Datos descifrados
	 * @return datos cifrados
	 * @throws Exception
	 */
	public static byte[] cifrar(byte[] datos) throws Exception {
		Crypt loSIACrypt = new Crypt(CLAVE_DES);
		return loSIACrypt.cifradoDatos(datos);
	}
	
	/**
	 * Realiza el descifrado simetrico
	 * 
	 * @param datos Datos cifrados
	 * @return datos descifrados
	 * @throws Exception
	 */
	public static byte[] descifrar(byte[] datos) throws Exception {
		Crypt loSIACrypt = new Crypt(CLAVE_DES);
		return loSIACrypt.descifradoDatos(datos);
	}
	
	/**
	 * Obtiene el resumen SHA1 del texto indicado
	 * @param psTextoClaro Texto claro
	 * @return resumen SHA1 del texto claro codificado en Base64
	 * @throws IllegalStateException
	 */
	public static String getSHA1(String psTextoClaro) throws IllegalStateException {
		MessageDigest md = null;

		try {
			md = MessageDigest.getInstance("SHA"); // Instancia de generador SHA-1
		}
		catch(NoSuchAlgorithmException e) {
			throw new IllegalStateException(e.getMessage());
		}

		try {
			md.update(psTextoClaro.getBytes("UTF-8")); // Generaci�n de resumen de mensaje
		}
		catch(UnsupportedEncodingException e) {
			throw new IllegalStateException(e.getMessage());
		}

		byte raw[] = md.digest(); // Obtenci�n del resumen de mensaje
		String hash = new String(Base64.encodeBase64(raw)); // Traducci�n a BASE64

		return hash;
	}
}
