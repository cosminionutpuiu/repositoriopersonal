package pruebas;

import java.util.StringTokenizer;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class Pruebas {
	private final static String ENTRADA_POR_CERTIFICADO = "1";
	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
	System.out.println(	Pattern.matches("\\w+([\\.]?\\w+)*", "manuel.toscano.ferrera"));
	
	String cadena="N=Ana;A1=Gonzalez;A2=Asian;";
	
	String patron="N=(.*?);A1=(.*?);A2=(.*?);";
	
	System.out.println(cadena.replaceAll(patron, "HOLA$1$2$3") );
	//Pattern pattern = Pattern.compile("\\w+([\\.]?\\w+)*");

	//Pattern.
	
	String localAttribute = "cn ###  N=(.*?); A1=(.*?); A2=(.*?); ###   HOLA $1 $2 $3";
    
	String campo =null;
	String valor =null;
	
    String patronEntrada ="N=Ana; A1=Gonzalez; A2=Asian;";
    String patronSalida =null;
    
    StringTokenizer tokenizer2 = 
            new StringTokenizer(localAttribute, "###");
    
    System.out.println(tokenizer2.countTokens());
        if (tokenizer2.countTokens() == 3) {
            campo = tokenizer2.nextToken().trim();
            patronEntrada = tokenizer2.nextToken().trim();
            patronSalida = tokenizer2.nextToken().trim();
        }
        
        
        System.out.println(" cadena a procesar " + cadena);
        System.out.println(" campo " + campo);
        System.out.println(" patronEntrada " + patronEntrada);
        System.out.println(" patronSalida " + patronSalida);
        
        
        
    	System.out.println("salida 2 -> " + cadena.replaceAll(patronEntrada, patronSalida) );
    	System.out.println("salida 3 -> " + cadena.replaceAll(patron, patronSalida) );
    	System.out.println("salida 4 ->" + cadena.replaceAll(patron, "ADIOS $1 $2 $3") );
	
    	
        Pattern p = Pattern.compile(patron);
        // get a matcher object
        Matcher m = p.matcher(cadena);
        String INPUT = m.replaceAll(patronSalida);
        System.out.println(INPUT);
String a = "1";
        System.out.println(ENTRADA_POR_CERTIFICADO.equalsIgnoreCase(a)); 
    	
    	
	
	}

}
