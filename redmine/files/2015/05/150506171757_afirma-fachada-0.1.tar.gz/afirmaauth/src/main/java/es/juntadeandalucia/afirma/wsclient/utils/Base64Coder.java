/**
 * European Union Public License
 * Empresa desarrolladora: SANDETEL
 * Autor: Junta de Andalucia.
 * Fecha Liberacion en 2012.
 *
 * Este programa es software libre: usted tiene derecho a redistribuirlo
 * y/o modificarlo bajo los terminos de la Licencia EUPL European Public
 * License publicada por el organismo IDABC de la Comision Europea, en su
 * version 1.0. o posteriores.
 *
 * Este programa se distribuye de buena fe, pero SIN NINGUNA GARANTIA,
 * incluso sin las presuntas garantias implicitas de USABILIDAD o
 * ADECUACION A PROPOSITO CONCRETO. Para mas informacion consulte la
 * Licencia EUPL European Public License.
 *
 * Usted recibe una copia de la Licencia EUPL European Public License junto
 * con este programa, si por algun motivo no le es posible visualizarla,
 * puede consultarla en la siguiente URL:
 * http://ec.europa.eu/idabc/servlets/Doc?id=31099
 *
 * You should have received a copy of the EUPL European Public License
 * along with this program. If not, see
 * http://ec.europa.eu/idabc/servlets/Doc?id=31096
 *
 * Sie sollten eine Kopie der EUPL European Public License zusammen mit
 * diesem Programm. Wenn nicht, finden Sie da
 * http://ec.europa.eu/idabc/servlets/Doc?id=29919
 */
package es.juntadeandalucia.afirma.wsclient.utils;


/**
 * Clase de utilidad de emplea el codificador en Base64 de la plataforma,
 * pero gestionando el error tanto en codificación como decodificación.
 * 
 * @author Procede del API de Afirma
 */
public class Base64Coder
{	
	// Tama�os para el c�lculo de codificaciones y decodificaciones en Base64 por trozos
	// 1 KB
	public static final int SIZE_1KB = 1000;
	// 10 KB
	public static final int SIZE_10KB = 10000;
	// 100 KB
	public static final int SIZE_100KB = 100000;
	// 1 MB
	public static final int SIZE_1MB = 10000000;
	
	/**
	 * M�todo que codifica un array de bytes en base 64.
	 * Empleado por las clases de firmado para codificar los datos, firmas
	 * o hashes antes de enviarlos por la red. En caso de no poder codificar los
	 * datos recibidos, se supondr�n ya codificados en Base64.
	 * 
	 * @param data Datos a codificar en Base64
	 * @return Datos codificados.
	 * @throws SignatureModuleException 
	 */
	public byte[] encodeBase64 (byte[] data) throws Exception
	{
		return encodeBase64(data, 0, data.length);
	}
	
	public byte[] encodeBase64 (byte[] data, int offset, int len) throws Exception
	{
		UtilsBase64 encoder = null;
		byte result [] = null;
		
		if (data == null)
			throw new NullPointerException("Error en el par�metro de entrada");

		try
		{
			encoder = new UtilsBase64();
			
			result = encoder.encodeBytes(data, offset, len).getBytes();
			
			return (result == null) ? data : result;
		}
		catch (Exception e)
		{
			throw new Exception("Error codificando los datos en Base64");
		}
	}
	
	/**
	 * M�todo que decodifica un array de bytes en base 64.
	 * Empleado por las clases de firmado para decodificar los datos, firmas
	 * o hashes recibidos. En caso de no poder decodificar los
	 * datos recibidos, se supondr�n ya decodificados en Base64.
	 * 
	 * @param data Datos codificados en Base64
	 * @return Datos decodificados.
	 * @throws Exception 
	 */
	public byte[] decodeBase64 (byte[] data) throws Exception
	{
		return decodeBase64(data, 0, data.length);
	}
	
	public byte[] decodeBase64 (byte[] data, int offset, int len) throws Exception
	{
		UtilsBase64 decoder = null;
		byte result [] = null;
		
		if (data == null)
			throw new NullPointerException("Error en el par�metro de entrada");

		try
		{
			decoder = new UtilsBase64();
			
			result = decoder.decode(data, offset, len);
			
			return (result == null) ? data : result;
		}
		catch (Exception e)
		{
			throw new Exception("Error decodificando los datos en Base64");
		}
	}
	
	public boolean isBase64Encoded(byte[] data) throws Exception
	{
		
		UtilsBase64 decoder = null;
		byte result[] = null;
		
		if (data==null)
			throw new NullPointerException("Error en el parametro de entrada");
		
		try{
			decoder = new UtilsBase64();
			
			result = decoder.decode(data, 0, data.length);
			
			if (result==null)
				return false;
			else
				return true;
		}catch(Exception e)
		{
			throw new Exception("Error comprobando si los datos est�n codificados en Base64");
		}
		

	}
	
	public static void main(String args[]){
		
		String dato = "sia2123";
		Base64Coder coder = new Base64Coder();
		try {
			String datosCod = new String (coder.encodeBase64(dato.getBytes()));
			System.out.println(datosCod);
			
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		
	}
}
