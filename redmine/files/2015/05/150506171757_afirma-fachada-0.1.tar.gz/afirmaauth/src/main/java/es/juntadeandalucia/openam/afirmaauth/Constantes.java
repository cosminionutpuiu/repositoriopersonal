/**
 * European Union Public License Empresa desarrolladora: SANDETEL Autor: Junta
 * de Andalucia. Fecha Liberacion en 2012.
 *
 * Este programa es software libre: usted tiene derecho a redistribuirlo y/o
 * modificarlo bajo los terminos de la Licencia EUPL European Public License
 * publicada por el organismo IDABC de la Comision Europea, en su version 1.0. o
 * posteriores.
 *
 * Este programa se distribuye de buena fe, pero SIN NINGUNA GARANTIA, incluso
 * sin las presuntas garantias implicitas de USABILIDAD o ADECUACION A PROPOSITO
 * CONCRETO. Para mas informacion consulte la Licencia EUPL European Public
 * License.
 *
 * Usted recibe una copia de la Licencia EUPL European Public License junto con
 * este programa, si por algun motivo no le es posible visualizarla, puede
 * consultarla en la siguiente URL:
 * http://ec.europa.eu/idabc/servlets/Doc?id=31099
 *
 * You should have received a copy of the EUPL European Public License along
 * with this program. If not, see
 * http://ec.europa.eu/idabc/servlets/Doc?id=31096
 *
 * Sie sollten eine Kopie der EUPL European Public License zusammen mit diesem
 * Programm. Wenn nicht, finden Sie da
 * http://ec.europa.eu/idabc/servlets/Doc?id=29919
 */
package es.juntadeandalucia.openam.afirmaauth;

public interface Constantes {

    public static final String AFIRMA_SERVICE_CAMPOS_LOGIN_DATASTORE = "afirma-service-campos-login-datastore"; // uid, numDoc
    public static final String AFIRMA_SERVICE_CAMPOS_NIF_DATASTORE = "afirma-service-campo-nif-datastore"; // numdoc
    public static final String AFIRMA_SERVICE_CAMPOS_NIF_CERTIFICADO = "afirma-service-campos-nif-certificado"; // NIFResponsable, NIF-CIF
    public static final String AFIRMA_SERVICE_CAMPO_RDN_DATASTORE = "afirma-service-campo-rdn-datastore"; // CN EN GUIA, UID EN CORREO
    public static final String AFIRMA_SERVICE_CAMPOS_NIFS_BLOQUEADOS = "afirma-service-campos-nifs-bloqueados";

    public static final String AFIRMA_FACHADA_SERVICE_CAMPOS_LOGIN_DATASTORE = "afirma-fachada-service-campos-login-datastore"; // uid, numDoc
    public static final String AFIRMA_FACHADA_SERVICE_CAMPOS_NIF_DATASTORE = "afirma-fachada-service-campo-nif-datastore"; // numdoc
    public static final String AFIRMA_FACHADA_SERVICE_CAMPOS_NIF_CERTIFICADO = "afirma-fachada-service-campos-nif-certificado"; // NIFResponsable, NIF-CIF
    public static final String AFIRMA_FACHADA_SERVICE_CAMPO_RDN_DATASTORE = "afirma-fachada-service-campo-rdn-datastore"; // CN EN GUIA, UID EN CORREO
    public static final String AFIRMA_FACHADA_SERVICE_CAMPOS_NIFS_BLOQUEADOS = "afirma-fachada-service-campos-nifs-bloqueados";

    public static final String ERROR_GENERICO = "error_generico";
    public static final String USUARIO_PASSWORD_INCORRECTO = "usuario_password_incorrecto";
    public static final String ERROR_AUTH_CERTIFICADOS = "error_auth_certificados";
    public static final String CERTIFICADO_NO_VALIDO = "certificado_no_valido";
    public static final String IDENTIFICADOR_NO_PERMITIDO = "error_identificador_no_permitido";
    public static final String USUARIO_NO_EN_SISTEMA = "usuario_no_en_sistema";
    public static final String IDENTIFICADOR_BLOQUEADO = "identificador_bloqueado";
    public static final String IDENTIFICADOR_DUPLICADO = "identificador_duplicado";

}
