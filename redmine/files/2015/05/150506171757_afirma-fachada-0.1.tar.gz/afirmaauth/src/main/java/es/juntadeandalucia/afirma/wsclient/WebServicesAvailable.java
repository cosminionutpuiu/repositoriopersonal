/**
 * European Union Public License
 * Empresa desarrolladora: SANDETEL
 * Autor: Junta de Andalucia.
 * Fecha Liberacion en 2012.
 *
 * Este programa es software libre: usted tiene derecho a redistribuirlo
 * y/o modificarlo bajo los terminos de la Licencia EUPL European Public
 * License publicada por el organismo IDABC de la Comision Europea, en su
 * version 1.0. o posteriores.
 *
 * Este programa se distribuye de buena fe, pero SIN NINGUNA GARANTIA,
 * incluso sin las presuntas garantias implicitas de USABILIDAD o
 * ADECUACION A PROPOSITO CONCRETO. Para mas informacion consulte la
 * Licencia EUPL European Public License.
 *
 * Usted recibe una copia de la Licencia EUPL European Public License junto
 * con este programa, si por algun motivo no le es posible visualizarla,
 * puede consultarla en la siguiente URL:
 * http://ec.europa.eu/idabc/servlets/Doc?id=31099
 *
 * You should have received a copy of the EUPL European Public License
 * along with this program. If not, see
 * http://ec.europa.eu/idabc/servlets/Doc?id=31096
 *
 * Sie sollten eine Kopie der EUPL European Public License zusammen mit
 * diesem Programm. Wenn nicht, finden Sie da
 * http://ec.europa.eu/idabc/servlets/Doc?id=29919
 */
package es.juntadeandalucia.afirma.wsclient;

import es.juntadeandalucia.afirma.wsclient.utils.Base64Coder;


public interface WebServicesAvailable {
	public Base64Coder base64Coder = new Base64Coder();

	// Servicios Web disponibles en el cliente Web Service
	

	// 2) de Firma
	public final String signatureValidationWebServiceName = "ValidarFirma";

	public final String getCertificateInfoWebServiceName = "ObtenerInfoCertificado";




	// 2) de Firma
	public static final String SignatureValidationRequest = "<?xml version=\"1.0\" encoding=\"UTF-8\"?>"
			+ "<mensajeEntrada targetNamespace=\"https://afirmaws/ws/firma\" xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\" xsi:noNamespaceSchemaLocation=\"https://localhost/afirmaws/xsd/mfirma/ws.xsd\">"
			+ "<peticion>ValidarFirma</peticion>"
			+ "<versionMsg>1.0</versionMsg>"
			+ "<parametros>"
			+ "<idAplicacion/>"
			+ "<firmaElectronica/>"
			+ "<formatoFirma/>"
			+ "<hash/>"
			+ "<algoritmoHash/>"
			+ "<datos/>"
			+ "</parametros>"
			+ "</mensajeEntrada>";


	public static final String GetCertificateInfoRequest = "<?xml version=\"1.0\" encoding=\"UTF-8\"?>"
			+ "<mensajeEntrada xmlns=\"https://afirmaws/ws/validacion\" xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\" xsi:SchemaLocation=\"https://localhost/afirmaws/xsd/mvalidacion/ws.xsd\">"
			+ "<peticion>ObtenerInfoCertificado</peticion>"
			+ "<versionMsg>1.0</versionMsg>"
			+ "<parametros>"
			+ "<idAplicacion/>"
			+ "<certificado/>"
			+ "</parametros>"
			+ "</mensajeEntrada>";

	
	
	//public void run(String[] args);

//	/**
//	 * M�todo que obtiene de la entrada la informaci�n necesaria para poder
//	 * ejecutar la l�gica del cliente
//	 * 
//	 * @param args
//	 *            Par�metros de entrada a la aplicaci�n.
//	 */
//	public void fillParameters(String[] args);
}
