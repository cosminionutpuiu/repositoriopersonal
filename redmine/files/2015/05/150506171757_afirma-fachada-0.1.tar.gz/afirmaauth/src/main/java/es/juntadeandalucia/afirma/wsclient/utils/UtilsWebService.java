/**
 * European Union Public License
 * Empresa desarrolladora: SANDETEL
 * Autor: Junta de Andalucia.
 * Fecha Liberacion en 2012.
 *
 * Este programa es software libre: usted tiene derecho a redistribuirlo
 * y/o modificarlo bajo los terminos de la Licencia EUPL European Public
 * License publicada por el organismo IDABC de la Comision Europea, en su
 * version 1.0. o posteriores.
 *
 * Este programa se distribuye de buena fe, pero SIN NINGUNA GARANTIA,
 * incluso sin las presuntas garantias implicitas de USABILIDAD o
 * ADECUACION A PROPOSITO CONCRETO. Para mas informacion consulte la
 * Licencia EUPL European Public License.
 *
 * Usted recibe una copia de la Licencia EUPL European Public License junto
 * con este programa, si por algun motivo no le es posible visualizarla,
 * puede consultarla en la siguiente URL:
 * http://ec.europa.eu/idabc/servlets/Doc?id=31099
 *
 * You should have received a copy of the EUPL European Public License
 * along with this program. If not, see
 * http://ec.europa.eu/idabc/servlets/Doc?id=31096
 *
 * Sie sollten eine Kopie der EUPL European Public License zusammen mit
 * diesem Programm. Wenn nicht, finden Sie da
 * http://ec.europa.eu/idabc/servlets/Doc?id=29919
 */

package es.juntadeandalucia.afirma.wsclient.utils;

import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.net.URL;
import java.util.HashMap;
import java.util.Properties;

import javax.xml.namespace.QName;

import org.apache.axis.client.Call;
import org.apache.axis.client.Service;
import org.apache.axis.constants.Use;
import org.apache.axis.message.SOAPEnvelope;
import org.apache.axis.utils.XMLUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.w3c.dom.CDATASection;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;
import org.w3c.dom.Text;

import es.juntadeandalucia.afirma.wsclient.ClientHandler;
import es.juntadeandalucia.afirma.wsclient.WebServicesAvailable;
import es.juntadeandalucia.utils.cripto.CifradorProperties;


public class UtilsWebService {
	
	 private static Log moLog = LogFactory.getLog(UtilsWebService.class);
	

	private javax.xml.parsers.DocumentBuilder db = null;

	private static Properties webServicesConfiguration = null;
	private static Properties securityConfiguration = null;

	// Timeout configurado para las llamadas a los servicios Web
	private static int TIMER;
	// Endpoint donde se localizan los servicios Web
	protected static String ENDPOINT = null;

	protected static String afirmaIP = null;
	protected static int afirmaPort;

	protected static String idAplicacion;

	
	private static UtilsWebService instance;
	
	private static javax.xml.parsers.DocumentBuilderFactory dbf;
	
	
	
	private void UtilsWebService(){

		
	}
	
	
	public static UtilsWebService getInstance(){
		
		if (instance==null)
		{
			instance=new UtilsWebService();
			instance.inicializar();
		}	
		return instance;
	}
	
	
	
	private void inicializar (){

		
		System.out.println("Inicializando Conexión @Firma");
		// Carga del fichero de configuraci�n de propiedades de seguridad
		securityConfiguration = new Properties();


		try {
			
			// Obtenci�n de un parseador de XML
			dbf = javax.xml.parsers.DocumentBuilderFactory.newInstance();
			dbf.setNamespaceAware(true);
			dbf.setIgnoringComments(true);
			
			
	
			URL url = null;//Thread.currentThread().getContextClassLoader().getResource("/");

			System.out.println("Localizando fichero de configuración securityConfiguration.properties");
			
			
			url = Thread.currentThread().getContextClassLoader().getResource("jdaConf/securityConfiguration.properties");
			
			if (url == null)
				url = Thread.currentThread().getContextClassLoader().getResource("securityConfiguration.properties");
			else if (url == null)
				url = Thread.currentThread().getContextClassLoader().getResource("WEB-INF/jdaConf/securityConfiguration.properties");

			
			if (url != null)
				System.out.println(" cargando configuración securityConfiguration.properties desde -> " + url);
			else {
				System.out.println("Error: no se ha podido encontrar el fichero de configuración securityConfiguration.properties");
				
			}

			securityConfiguration = new Properties();
			securityConfiguration.load(new FileInputStream(new File(url.getFile())));
			
			//Ciframos la contrase�a de @Firma
			moLog.debug("[OpenAM - Cifrando contrase�as si procediera...]");
			String[] paramsToCipher =  new String[] {"security.usertoken.password"};
			CifradorProperties cipher = new CifradorProperties(paramsToCipher);
			cipher.cifradoDatosConfiguracon(securityConfiguration, url.toExternalForm());
			moLog.debug("[OpenAM - Contrase�as cifradas!]");
			
	
			instance.idAplicacion = securityConfiguration.getProperty("id.aplicacion");
			System.out.println("Parámetro idAplicacion=" + instance.idAplicacion );
			

		} catch (Exception e) {
			moLog.error("[OpenAM - No se ha aencontrado el fichero de properties para la configuracion de seguridad]");
			
		}

		// Carga del fichero de configuraci�n de propiedades de los servicios
		// Web
		webServicesConfiguration = new Properties();
		try{
			
			
			URL url = Thread.currentThread().getContextClassLoader().getResource("jdaConf/webServicesConfiguration.properties");
			
			if (url == null)
				url = Thread.currentThread().getContextClassLoader().getResource("webServicesConfiguration.properties");
			else if (url == null)
				url = Thread.currentThread().getContextClassLoader().getResource("/WEB-INF/jdaConf/webServicesConfiguration.properties");

			
			if (url != null)
				System.out.println(" cargando configuración webServicesConfiguration.propertie desde -> " + url);
			else {
				System.out.println("Error: no se ha podido encontrar el fichero de configuración webServicesConfiguration.propertie");
				
			}
			

			webServicesConfiguration = new Properties();
			webServicesConfiguration.load(new FileInputStream(new File(url.getFile())));
			
			// protocolo
			String afirmaProtocol = webServicesConfiguration.getProperty("afirma.protocol");
			afirmaProtocol = (afirmaProtocol == null || afirmaProtocol.trim().equals("")) ? "http" : afirmaProtocol.trim();

			// ip
			afirmaIP = webServicesConfiguration.getProperty("afirma.ip");
			if (afirmaIP == null || afirmaIP.equals(""))
				throw new Exception("La direcci�n IP debe definirse");
			else
				afirmaIP = afirmaIP.trim();

			// puerto
			String afirmaPortAux = webServicesConfiguration.getProperty("afirma.port");
			afirmaPort = (afirmaPortAux == null || afirmaPortAux.trim().equals("")) ? 80 : Integer.parseInt(afirmaPortAux.trim());

			// sufijo
			String afirmaSufix = webServicesConfiguration.getProperty("afirma.sufix");
			afirmaSufix = (afirmaSufix == null) ? "" : afirmaSufix.trim();

			// Direcci�n IP donde est� localizada la plataforma @firma 5.0 +
			// ruta a los servicios dentro del servidor Web
			ENDPOINT = afirmaProtocol + "://" + afirmaIP + ":" + afirmaPort	+ afirmaSufix;

			// Timer para el timeout en el socket
			// TIMER = 0 --> Socket bloqueante
			String timer = webServicesConfiguration.getProperty("socket.timer");
			TIMER = (timer == null || timer.equals("")) ? 0 : Integer.parseInt(timer.trim());


		}catch (Throwable t) {
			moLog.error("[OpenAM - No se ha aencontrado el fichero de properties para los servicios Web]",t);
		}
	}
	
	// FIRMA

	/**
	 * Prepara la petici�n al Servicio Web "ValidarFirmaWS", con los par�metros
	 * indicados.
	 * 
	 * @param eSignature
	 *            Firma Electr�nica a validar (codificada en Base64)
	 * @param eSignatureFormat
	 *            Formato de la Firma Electr�nica a validar
	 * @param hash
	 *            Hash de los datos firmados codificado en Base64.
	 * @param hashAlgorithm
	 *            Algoritmo de hash empleado en el c�lculo del hash anterior
	 * @param data
	 *            Datos originales firmados codificados en Base64.
	 */
	public  Document prepareValidateSignatureRequest(String eSignature, String eSignatureFormat,
			byte[] hash, String hashAlgorithm, byte[] data) {
		
		moLog.debug("[prepareValidateSignatureRequest]");

		try {
			db = dbf.newDocumentBuilder();
			Document signatureValidationRequest = db
					.parse(new ByteArrayInputStream(
							WebServicesAvailable.SignatureValidationRequest
									.getBytes("UTF-8")));

			// Id de aplicaci�n
			NodeList applicationNode = signatureValidationRequest
					.getElementsByTagName("idAplicacion");
			Text applicationValueNode = signatureValidationRequest
					.createTextNode(instance.idAplicacion);
			applicationNode.item(0).appendChild(applicationValueNode);

			// Firma Electr�nica a validar
			NodeList eSignatureNode = signatureValidationRequest
					.getElementsByTagName("firmaElectronica");
			CDATASection eSignatureValueNode = signatureValidationRequest
					.createCDATASection(eSignature);
			eSignatureNode.item(0).appendChild(eSignatureValueNode);

			// Formato de firma
			NodeList eSignatureFormatNode = signatureValidationRequest
					.getElementsByTagName("formatoFirma");
			Text eSignatureFormatValueNode = signatureValidationRequest
					.createTextNode(eSignatureFormat);
			eSignatureFormatNode.item(0).appendChild(eSignatureFormatValueNode);

			// Algoritmo de hash
			if (hash != null) {
				NodeList hashNode = signatureValidationRequest
						.getElementsByTagName("hash");
				CDATASection hashValueNode = signatureValidationRequest
						.createCDATASection(new String(hash));
				hashNode.item(0).appendChild(hashValueNode);

				NodeList hashAlgorithmNode = signatureValidationRequest
						.getElementsByTagName("algoritmoHash");
				Text hashAlgorithmValueNode = signatureValidationRequest
						.createTextNode(hashAlgorithm);
				hashAlgorithmNode.item(0).appendChild(hashAlgorithmValueNode);
			}

			// Datos
			if (data != null) {
				NodeList dataNode = signatureValidationRequest
						.getElementsByTagName("datos");
				CDATASection dataValueNode = signatureValidationRequest
						.createCDATASection(new String(data));
				dataNode.item(0).appendChild(dataValueNode);
			}

			return signatureValidationRequest;
		} catch (Exception e) {
			moLog.error("Se ha producido un error generando la petici�n de validaci�n de firma",e);
			return null;
		}
	}

	/**
	 * Prepara la petici�n al Servicio Web "ObtenerInfoCertificado", con los
	 * par�metros indicados.
	 * 
	 * @param appId
	 *            Identificador de la aplicaci�n
	 * @param certificate
	 *            Certificado a validar
	 */
	public Document prepareGetCertificateInfoRequest( String certificate) {
		try {
			db = dbf.newDocumentBuilder();
			Document getCertificateInfoRequest = db
					.parse(new ByteArrayInputStream(
							WebServicesAvailable.GetCertificateInfoRequest
									.getBytes("UTF-8")));

			
			
			// Id de aplicaci�n
			NodeList aplicationNode = getCertificateInfoRequest
					.getElementsByTagName("idAplicacion");
			Text aplicationValueNode = getCertificateInfoRequest
					.createTextNode(instance.idAplicacion);
			aplicationNode.item(0).appendChild(aplicationValueNode);

			// certificado
			NodeList certificateNode = getCertificateInfoRequest
					.getElementsByTagName("certificado");
			CDATASection certificateValueNode = getCertificateInfoRequest
					.createCDATASection(certificate);
			certificateNode.item(0).appendChild(certificateValueNode);

			return getCertificateInfoRequest;
		} catch (Exception e) {
			moLog.error("Se ha producido un error generando la petici�n de validaci�n de certificados.",e);
			return null;
		}
	}

	/**
	 * M�todo que permite enviar una petici�n a un servicio Web determinado,
	 * usando AXIS.
	 * 
	 * @param webService
	 *            Nombre del servicio Web al que invocar
	 * @param request
	 *            Petici�n a enviar
	 * @return Respuesta devuelta por el servicio Web
	 */
	public  String launchRequest(String webService,Document request) {
			return lanchRequestOtherOperationalMode(webService, webService,	request);
	}

	private  String lanchRequestOtherOperationalMode(String webService,
			String operation, Document request) {
		ClientHandler sender = null;

		try {
			// Creacion del manejador que securizar� la petici�n SOAP
			sender = new ClientHandler(securityConfiguration);
			Service service = new Service();

			Call call = (Call) service.createCall();

			call.setTargetEndpointAddress(new java.net.URL(ENDPOINT
					+ webService));
			call.setOperationName(new QName("http://soapinterop.org/",
					operation));
			call.setOperationUse(Use.LITERAL);
			call.setTimeout(new Integer(TIMER));
			call.setClientHandlers(sender, null);

			String param = operation + "Request";

			call.addParameter(param, org.apache.axis.Constants.XSD_STRING,
					javax.xml.rpc.ParameterMode.IN);
			call.setReturnType(org.apache.axis.Constants.XSD_STRING);

			long requestTime = System.currentTimeMillis();

			String soapRequest = "<?xml version=\"1.0\" encoding=\"UTF-8\"?>"
					+ "<soapenv:Envelope "
					+ "xmlns:soapenv=\"http://schemas.xmlsoap.org/soap/envelope/\" xmlns:xsd=\"http://www.w3.org/2001/XMLSchema\" "
					+ "xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\">"
					+ "<soapenv:Body>"
					+ "<"
					+ operation
					+ " xmlns=\"http://soapinterop.org/\">"
					+ "<"
					+ operation
					+ "Request xsi:type=\"xsd:string\" xmlns=\"\">"
					+ XMLUtils.xmlEncodeString(XMLUtils.DocumentToString(request)) + "</" + operation
					+ "Request>" + "</" + operation + "></soapenv:Body>"
					+ "</soapenv:Envelope>";

			SOAPEnvelope soapPeticion = new SOAPEnvelope(
					new ByteArrayInputStream(soapRequest.getBytes()));
			// if (StartingClassWS.ALMACENAR_PETICION) {
			// UtilsFileSystem.writeDataToFileSystem(soapPeticion.getAsString().getBytes(),
			// StartingClassWS.construyeRutaPetRes(true, webService));
			// }
			SOAPEnvelope soapRespuesta = call.invoke(soapPeticion);
			
			
			System.out.println(soapRespuesta);
			String resp = XMLUtils.DocumentToString(soapRespuesta.getBody()
					.getFirstChild().getFirstChild().getFirstChild()
					.getOwnerDocument());
			resp = soapRespuesta.getBody().getFirstChild().getFirstChild()
					.getFirstChild().getNodeValue();
			// String resp = soapRespuesta.getBody().getOwnerDocument();

			// if (StartingClassWS.ALMACENAR_RESPUESTA) {
			// UtilsFileSystem.writeDataToFileSystem(soapRespuesta.getAsString().getBytes(),
			// StartingClassWS.construyeRutaPetRes(false, webService));
			// }

			long tiempoRespuesta = System.currentTimeMillis();

			long resultado = tiempoRespuesta - requestTime;

			moLog.debug("[OpenAM - Tiempo de Respuesta [" + resultado + "]]");

			return resp;
		} catch (Exception e) {
			moLog.error("EXCEPTION - Se ha producido un error enviando la petici�n a "+ ENDPOINT + webService,e);
			return null;
		} catch (Throwable t){
			moLog.error("THROWABLE -Se ha producido un error enviando la petici�n a "+ ENDPOINT + webService,t);
			return null;
		}
	}

	/**
	 * M�todo que obtiene la informaci�n XML (los hijos) del nodo indicado del
	 * documento XML proporcionado.
	 * 
	 * @param document
	 *            Documento XML
	 * @param nodeTag
	 *            Nombre del nodo del cual extrae la informaci�n
	 * @return Valor XML contenido a partir del nodo indicado
	 */
	public  String getXMLChildsFromDocumentNode(
			String document, String nodeTag) {
		try {
			db = dbf.newDocumentBuilder();
			Document doc = db.parse(new ByteArrayInputStream(document
					.getBytes("UTF-8")));

			NodeList docNode = doc.getElementsByTagName(nodeTag);
			//moLog.debug(docNode.item(0).getFirstChild().getNodeValue());
			return XMLUtils.ElementToString((Element) docNode.item(0)
					.getFirstChild());
		} catch (Exception e) {
			moLog.error("getXMLChildsFromDocumentNode",e);
			return null;
		}
	}

	/**
	 * @author icendrero
	 * M�todo para obtener el valor de un nodo de un documento XML
	 * 
	 * @param document
	 * 				Documento XML
	 * @param nodeTag
	 * 				Nodo del que recuperar el valor
	 * @return Valor del nodo a buscar
	 * 	
	 */
	public  String getNodeValueFromDocument(String document,
			String nodeTag) {
		try {
			db = dbf.newDocumentBuilder();
			Document doc = db.parse(new ByteArrayInputStream(document
					.getBytes("UTF-8")));

			NodeList docNode = doc.getElementsByTagName(nodeTag);
			return (docNode.item(0).getFirstChild().getNodeValue());
		} catch (Exception e) {
			moLog.error("getNodeValueFromDocument",e);
			return null;
		}
	}

	
	/**
	 * @author icendrero
	 * 
	 * M�todo que parsea en un HashMap todos los valores devueltos por la petici�n ObtenerInfoCertificado
	 * 
	 * @param document Documento que representa una respuesta de ObtenerInfoResultado
	 * @return HashMap clave-valor con todos los datos del certificado
	 */
	public  HashMap<String, String> getCertificateInfoParsed(
			String document) {
		HashMap<String, String> certificate = new HashMap<String, String>();
		try {
			db = dbf.newDocumentBuilder();
			Document doc = db.parse(new ByteArrayInputStream(document.getBytes("UTF-8")));
			NodeList docNodes = doc.getElementsByTagName("Campo");
			for (int i = 0; i < docNodes.getLength(); i++) {
				NodeList campo = docNodes.item(i).getChildNodes();
				certificate.put(
						campo.item(0).getFirstChild().getNodeValue(),
						campo.item(1).getFirstChild().getNodeValue());
			}
		} catch (Exception e) {
			moLog.error("getCertificateInfoParsed",e);
			return null;
		}
		//moLog.debug(certificate);
		return certificate;
	}

	/**
	 * M�todo que indica si la respuesta de la plataforma ha sido correcta o no
	 * 
	 * @param response
	 *            Respuesta XML de la plataforma
	 * @return true en caso afirmativo, false en caso contrario
	 */
	public  boolean isCorrect(String response) {
		Document responseDoc = null;

		try {
			db = dbf.newDocumentBuilder();
			responseDoc = db.parse(new ByteArrayInputStream(response
					.getBytes("UTF-8")));
		} catch (Exception e) {
			moLog.error("Se ha producido un error obteniendo el estado de la respuesta",e);
			
			return false;
		}

		try {
			NodeList statusNode = null;

			statusNode = responseDoc.getElementsByTagName("estado");

			return new Boolean(statusNode.item(0).getFirstChild()
					.getNodeValue()).booleanValue();
		} catch (Exception e) {
			// Comprobamos si hemos recibido una excepcion
			try {
				// Codigo de error
				NodeList errorCodeNode = responseDoc
						.getElementsByTagName("codigoError");
				// descripcion del error
				NodeList descripcionErrorNode = responseDoc
						.getElementsByTagName("descripcion");

				moLog.error(errorCodeNode.item(0).getFirstChild()
						.getNodeValue()
						+ ": "
						+ descripcionErrorNode.item(0).getFirstChild()
								.getNodeValue());
				return false;
			} catch (Exception ee) {
				moLog.error(response , ee);
				return false;
			}
		}
	}

	/**
	 * M�todo que indica si la respuesta de una peticion de Obtencion de
	 * Informacion de Certificado a la plataforma ha sido correcta o no
	 * 
	 * @param response
	 *            Respuesta XML de la plataforma
	 * @return true en caso afirmativo, false en caso contrario
	 */
	public  boolean isCorrectGetCertificateInfoRequest(
			String response) {
		try {
			db = dbf.newDocumentBuilder();
			Document responseDoc = db.parse(new ByteArrayInputStream(response
					.getBytes("UTF-8")));

			NodeList statusNode = null;

			// Si existe el nodo InfoCertificado significa que la peticion ha
			// sido satisfactoria
			statusNode = responseDoc.getElementsByTagName("InfoCertificado");

			if (statusNode.getLength() == 0)
				return false;

			return true;
		} catch (Exception e) {
			moLog.error("Se ha producido un error obteniendo el estado de la respuesta",e);
			
			return false;
		}
	}


}