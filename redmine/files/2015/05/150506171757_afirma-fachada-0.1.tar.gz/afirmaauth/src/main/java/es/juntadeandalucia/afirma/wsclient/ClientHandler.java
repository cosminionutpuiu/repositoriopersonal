/**
 * European Union Public License
 * Empresa desarrolladora: SANDETEL
 * Autor: Junta de Andalucia.
 * Fecha Liberacion en 2012.
 *
 * Este programa es software libre: usted tiene derecho a redistribuirlo
 * y/o modificarlo bajo los terminos de la Licencia EUPL European Public
 * License publicada por el organismo IDABC de la Comision Europea, en su
 * version 1.0. o posteriores.
 *
 * Este programa se distribuye de buena fe, pero SIN NINGUNA GARANTIA,
 * incluso sin las presuntas garantias implicitas de USABILIDAD o
 * ADECUACION A PROPOSITO CONCRETO. Para mas informacion consulte la
 * Licencia EUPL European Public License.
 *
 * Usted recibe una copia de la Licencia EUPL European Public License junto
 * con este programa, si por algun motivo no le es posible visualizarla,
 * puede consultarla en la siguiente URL:
 * http://ec.europa.eu/idabc/servlets/Doc?id=31099
 *
 * You should have received a copy of the EUPL European Public License
 * along with this program. If not, see
 * http://ec.europa.eu/idabc/servlets/Doc?id=31096
 *
 * Sie sollten eine Kopie der EUPL European Public License zusammen mit
 * diesem Programm. Wenn nicht, finden Sie da
 * http://ec.europa.eu/idabc/servlets/Doc?id=29919
 */
package es.juntadeandalucia.afirma.wsclient;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.util.Properties;

import javax.xml.soap.MessageFactory;
import javax.xml.soap.SOAPMessage;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

import org.apache.axis.MessageContext;
import org.apache.axis.SOAPPart;
import org.apache.axis.handlers.BasicHandler;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.apache.ws.security.WSConstants;
import org.apache.ws.security.message.WSSecHeader;
import org.apache.ws.security.message.WSSecUsernameToken;
import org.w3c.dom.Document;
import org.w3c.dom.Element;

/**
 * Clase encargada de securizar los mensajes SOAP de petici�n realizados desde un cliente.
 * @author SEPAOT
 *
 */
public class ClientHandler extends BasicHandler 
{	
	private static final long serialVersionUID = 1L;

	// Log
	 private static Log moLog = LogFactory.getLog(ClientHandler.class);
	
	// Seguridad UserNameToken
	public static final String USERNAMEOPTION = WSConstants.USERNAME_TOKEN_LN;
	// Seguridad BinarySecurityToken
	public static final String CERTIFICATEOPTION = WSConstants.BINARY_TOKEN_LN;
	// Sin seguridad
	public static final String NONEOPTION = "None";
		
	// Opci�n de seguridad del objeto actual
	private String securityOption = null;
	
	// Usuario para el token de seguridad UserNameToken. 
	private String userTokenUserName = null;
	
	// Password para el token de seguridad UserNameToken 
	private String userTokenUserPassword = null;
	
	// Tipo de password para el UserNameTokenPassword
	private String userTokenUserPasswordType = null;
	

	/**
	 * Constructor que inicializa el atributo securityOption
	 * 
	 * @param securityOption opci�n de seguridad.
	 * @throws Exception
	 */
	public ClientHandler(Properties config)
	{
		if(config == null)
		{
			moLog.error("Fichero de configuracion de propiedades nulo");
		}

		try
		{
			securityOption = config.getProperty("security.mode");
			if (securityOption != null)
				securityOption=securityOption.trim();
			
			userTokenUserName = config.getProperty("security.usertoken.user");
			if (userTokenUserName != null)
				userTokenUserName=userTokenUserName.trim();
			
			userTokenUserPassword = config.getProperty("security.usertoken.password");
			if (userTokenUserPassword != null)
				userTokenUserPassword=userTokenUserPassword.trim();
			
			userTokenUserPasswordType = config.getProperty("security.usertoken.passwordType");
			if (userTokenUserPasswordType != null)
				userTokenUserPasswordType=userTokenUserPasswordType.trim();
			
		}
		catch (Exception e)
		{e.printStackTrace();
			moLog.error("Error leyendo el fichero de configuraci�n de securizaci�n");
			
		}
		
		if(!securityOption.equals(USERNAMEOPTION) && !securityOption.equals(CERTIFICATEOPTION) && !securityOption.equals(NONEOPTION))
		{
			moLog.error("Opcion de seguridad no valida: " + securityOption);
			
		}
	}
	
	public void invoke(MessageContext msgContext) 
	{
		SOAPMessage msg, secMsg;
		Document doc = null;

		secMsg = null;

		try 
		{
			//Obtenci�n del documento XML que representa la petici�n SOAP
        	msg = msgContext.getCurrentMessage();
        	
        	doc = ((org.apache.axis.message.SOAPEnvelope) msg.getSOAPPart().getEnvelope()).getAsDocument();
        	
        	//Securizaci�n de la petici�n SOAP seg�n la opcion de seguridad configurada
        	if(this.securityOption.equals(USERNAMEOPTION))
        		secMsg = this.createUserNameToken(doc);
//        	else if(this.securityOption.equals(CERTIFICATEOPTION))
//        		secMsg = this.createBinarySecurityToken(doc);
        	else
        		secMsg = msg;
        	
        	//Modificaci�n de la petici�n SOAP
            ((SOAPPart) msgContext.getRequestMessage().getSOAPPart()).
            	setCurrentMessage(secMsg.getSOAPPart().getEnvelope(), SOAPPart.FORM_SOAPENVELOPE);
        } 
		catch (Exception e) 
		{
        	moLog.error(e.getMessage());
        	
        }
	}

	/**
	 * Securiza, mediante el tag userNameToken, una petici�n SOAP no securizada.
	 * 
	 * @param soapRequest Documento xml que representa la petici�n SOAP sin securizar.
	 * @return Un mensaje SOAP que contiene la petici�n SOAP de entrada securizada 
	 * mediante el tag userNameToken.
	 */
	private SOAPMessage createUserNameToken(Document soapEnvelopeRequest)
	{
		ByteArrayOutputStream baos;
		Document secSOAPReqDoc;
		DOMSource source;
		Element element;
		SOAPMessage res;
		StreamResult streamResult;
		String secSOAPReq;
		WSSecUsernameToken wsSecUsernameToken;
		WSSecHeader wsSecHeader;

		try
		{
			//Inserci�n del tag wsse:Security y userNameToken
			wsSecHeader = new WSSecHeader(null,false);
			wsSecUsernameToken = new WSSecUsernameToken();
			wsSecUsernameToken.setPasswordType(this.userTokenUserPasswordType);
			wsSecUsernameToken.setUserInfo(this.userTokenUserName, this.userTokenUserPassword);
			wsSecHeader.insertSecurityHeader(soapEnvelopeRequest);
			wsSecUsernameToken.prepare(soapEnvelopeRequest);
			
	    	//A�adimos una marca de tiempo inidicando la fecha de creaci�n del tag
			wsSecUsernameToken.addCreated();
			wsSecUsernameToken.addNonce();
			
			//Modificaci�n de la petici�n
			secSOAPReqDoc = wsSecUsernameToken.build(soapEnvelopeRequest,wsSecHeader);
			element = secSOAPReqDoc.getDocumentElement();
	
	    	//Transformaci�n del elemento DOM a String
	        source = new DOMSource(element);
	        baos = new ByteArrayOutputStream();
	        streamResult = new StreamResult(baos);
	        TransformerFactory.newInstance().newTransformer().transform(source, streamResult);
	        secSOAPReq = new String(baos.toByteArray());
	
	        //Creaci�n de un nuevo mensaje SOAP a partir del mensaje SOAP securizado formado
	        MessageFactory mf = new org.apache.axis.soap.MessageFactoryImpl();
	        res = mf.createMessage(null,new ByteArrayInputStream(secSOAPReq.getBytes()));
	
			return res;
		}
		catch (Exception e) 
		{
        	moLog.error(e.getMessage());
        	
        	return null;
        }
	}
		
}
