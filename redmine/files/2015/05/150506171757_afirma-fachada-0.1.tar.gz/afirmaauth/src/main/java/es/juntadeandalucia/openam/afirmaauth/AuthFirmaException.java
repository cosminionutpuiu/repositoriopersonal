/**
 * European Union Public License
 * Empresa desarrolladora: SANDETEL
 * Autor: Junta de Andalucia.
 * Fecha Liberacion en 2012.
 *
 * Este programa es software libre: usted tiene derecho a redistribuirlo
 * y/o modificarlo bajo los terminos de la Licencia EUPL European Public
 * License publicada por el organismo IDABC de la Comision Europea, en su
 * version 1.0. o posteriores.
 *
 * Este programa se distribuye de buena fe, pero SIN NINGUNA GARANTIA,
 * incluso sin las presuntas garantias implicitas de USABILIDAD o
 * ADECUACION A PROPOSITO CONCRETO. Para mas informacion consulte la
 * Licencia EUPL European Public License.
 *
 * Usted recibe una copia de la Licencia EUPL European Public License junto
 * con este programa, si por algun motivo no le es posible visualizarla,
 * puede consultarla en la siguiente URL:
 * http://ec.europa.eu/idabc/servlets/Doc?id=31099
 *
 * You should have received a copy of the EUPL European Public License
 * along with this program. If not, see
 * http://ec.europa.eu/idabc/servlets/Doc?id=31096
 *
 * Sie sollten eine Kopie der EUPL European Public License zusammen mit
 * diesem Programm. Wenn nicht, finden Sie da
 * http://ec.europa.eu/idabc/servlets/Doc?id=29919
 */
package es.juntadeandalucia.openam.afirmaauth;

public class AuthFirmaException extends Exception {

	
	private String codigo = "";
			

	public void setCodigo(String codigo) {
		this.codigo = codigo;
	}

	public String getCodigo() {
		return codigo;
	}

	public AuthFirmaException(String codigo, String message, Throwable cause) {
		super(message, cause);
		this.codigo = codigo;

	}
	
	public AuthFirmaException(String codigo, String message) {
		super(message);
		this.codigo = codigo;

	}

	public AuthFirmaException(String codigo) {
		super();
		this.codigo = codigo;

	}

	public AuthFirmaException(String codigo,Throwable cause) {
		super(cause);
		this.codigo = codigo;

	}

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	
	
}
