/**
 * European Union Public License
 * Empresa desarrolladora: SANDETEL
 * Autor: Junta de Andalucia.
 * Fecha Liberacion en 2012.
 *
 * Este programa es software libre: usted tiene derecho a redistribuirlo
 * y/o modificarlo bajo los terminos de la Licencia EUPL European Public
 * License publicada por el organismo IDABC de la Comision Europea, en su
 * version 1.0. o posteriores.
 *
 * Este programa se distribuye de buena fe, pero SIN NINGUNA GARANTIA,
 * incluso sin las presuntas garantias implicitas de USABILIDAD o
 * ADECUACION A PROPOSITO CONCRETO. Para mas informacion consulte la
 * Licencia EUPL European Public License.
 *
 * Usted recibe una copia de la Licencia EUPL European Public License junto
 * con este programa, si por algun motivo no le es posible visualizarla,
 * puede consultarla en la siguiente URL:
 * http://ec.europa.eu/idabc/servlets/Doc?id=31099
 *
 * You should have received a copy of the EUPL European Public License
 * along with this program. If not, see
 * http://ec.europa.eu/idabc/servlets/Doc?id=31096
 *
 * Sie sollten eine Kopie der EUPL European Public License zusammen mit
 * diesem Programm. Wenn nicht, finden Sie da
 * http://ec.europa.eu/idabc/servlets/Doc?id=29919
 */
package es.juntadeandalucia.openam.afirmaauth;

import java.security.Principal;
import java.security.SecureRandom;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Map;
import java.util.ResourceBundle;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.security.auth.Subject;
import javax.security.auth.callback.Callback;
import javax.security.auth.callback.NameCallback;
import javax.security.auth.callback.PasswordCallback;

import com.iplanet.sso.SSOException;
import com.sun.identity.authentication.spi.AMLoginModule;
import com.sun.identity.authentication.spi.InvalidPasswordException;
import com.sun.identity.authentication.spi.UserNamePasswordValidationException;
import com.sun.identity.authentication.util.ISAuthConstants;
import com.sun.identity.idm.AMIdentity;
import com.sun.identity.idm.AMIdentityRepository;
import com.sun.identity.idm.IdRepoException;
import com.sun.identity.idm.IdSearchResults;
import com.sun.identity.idm.IdType;
import com.sun.identity.shared.datastruct.CollectionHelper;
import com.sun.identity.shared.debug.Debug;

import es.juntadeandalucia.afirma.wsclient.certificate.ObtenerInfoCertificado;
import es.juntadeandalucia.afirma.wsclient.eSignature.ValidarFirma;
import es.juntadeandalucia.afirma.wsclient.utils.Base64Coder;

@SuppressWarnings({ "unchecked", "rawtypes" })
public class Afirma extends AMLoginModule {

	public static final String MODULE_NAME = "Afirma";
	public static final String BUNDLE_NAME = "amAuthAfirma";
	private static final String AUTHLEVEL = "sunAMAuthAfirmaAuthLevel";
	private static Debug debug = Debug.getInstance(MODULE_NAME);

	private ResourceBundle bundle;

	private Map currentConfig = null;
	private Map sharedState = null;
	// private String authenticatedUser = null; // uid usuario logado.

	private AfirmaPrincipal principal;
	// Estados

	private final static String ENTRADA_POR_CERTIFICADO = "1";
	private final static int STATE_ENTRADA_PRINCIPAL = 1;
	private final static int STATE_CERT = 2;
	// private final static int STATE_ERROR = 1;

	protected String validatedUserID;
	private String userName;
	private String userPassword;

	/**
	 * Constructor
	 */
	public Afirma() {
		debug.message("In Afirma.Afirma()");
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	public void init(Subject subject, Map sharedState, Map options) {
		debug.message("Inicializando módulo autenticación User/Pass y @firma ");
		// BasicConfigurator.configure();

		/*
		 * System.setProperty("javax.net.ssl.trustStore",
		 * "/home/mantos/Escritorio/stsconf/client.keystore");
		 * 
		 * System.setProperty("javax.net.ssl.trustStorePassword", "changeit");
		 */
		limpiarErrores();

		// limpiarSession();

		if (debug.messageEnabled()) { // DEBUG,

			debug.message("****Contenido de sharedState****");

			for (Iterator iterator = sharedState.keySet().iterator(); iterator
					.hasNext();) {
				String object = (String) iterator.next();
				debug.message("key " + object + " valor="
						+ sharedState.get(object));
			}

			debug.message("****Contenido de options****");

			for (Iterator iterator = options.keySet().iterator(); iterator
					.hasNext();) {
				Object object = iterator.next();
				debug.message("key " + object + " valor=" + options.get(object));

			}
		}

		this.sharedState = sharedState;
		this.currentConfig = options;

		bundle = amCache.getResBundle(BUNDLE_NAME, getLoginLocale());

		if (debug.messageEnabled()) { // DEBUG,

			debug.message("****Contenido de bundle amAuthAfirma.properties****");

			for (Iterator<String> iterator = bundle.keySet().iterator(); iterator
					.hasNext();) {
				String object = iterator.next();
				debug.message("key " + object + " valor="
						+ bundle.getString(object));

			}
		}

		String authLevel = CollectionHelper.getMapAttr(options, AUTHLEVEL);
		if (authLevel != null) {
			try {
				setAuthLevel(Integer.parseInt(authLevel));
			} catch (Exception e) {
				debug.error("Unable to set auth level " + authLevel, e);
			}
		}
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	public int process(Callback[] callbacks, int state) {

		debug.message("Procesando petición ");
		debug.message("Estado: " + state);
		String identificadorEntrada = ""; // copia del identificador de logado
											// para su recuperación en caso de
											// error
		try {

			switch (state) {

			case STATE_ENTRADA_PRINCIPAL:
				Callback[] idCallbacks = new Callback[2];
				limpiarErrores();

				String isLoginCert = super.getHttpServletRequest()
						.getParameter("isLoginCert");

				// Se analiza si el submit desde la pg de login, ha sido para
				// entrar por certificado o para hacer login...

				if ("1".equalsIgnoreCase(isLoginCert)) { // Entrada
																				// por
					// certificado

					debug.message("Se ha seleccionado Login con certificado, Generando el desafio para la autenticación");

					// Nota: SecureRandom no es threadsafe... en java7 hay una
					// versión threadsafe

					SecureRandom rand = null;
					String randomNumberB64 = "";
					try {
						rand = SecureRandom.getInstance("SHA1PRNG");
						Base64Coder coder = new Base64Coder(); // clase de
																// @firma

						randomNumberB64 = new String(coder.encodeBase64(rand
								.generateSeed(40)));

						super.getHttpServletRequest().getSession()
								.setAttribute("desafio", randomNumberB64);

					} catch (Exception e) {
						debug.error(e.getMessage(), e);
						generaMensajeErrorUsuario(Constantes.ERROR_GENERICO);
						return STATE_ENTRADA_PRINCIPAL;
					}

					debug.message("Rediriguiendo hacia la página de autenticación con Certificado");
					return STATE_CERT;
				} else { // Entrada por Usuario/Password

					try {
						debug.message("Se ha seleccionado Login con Usuario/Password");
						// captura del user/password -> copia del código del
						// módulo DataStore presente en OpenAM....

						if (callbacks != null && callbacks.length == 0) {
							userName = (String) sharedState.get(getUserKey());
							userPassword = (String) sharedState
									.get(getPwdKey());
							if (userName == null || userPassword == null) {
								return ISAuthConstants.LOGIN_START;
							}
							NameCallback nameCallback = new NameCallback(
									"dummy");
							nameCallback.setName(userName);
							idCallbacks[0] = nameCallback;
							PasswordCallback passwordCallback = new PasswordCallback(
									"dummy", false);
							passwordCallback.setPassword(userPassword
									.toCharArray());
							idCallbacks[1] = passwordCallback;
						} else {
							idCallbacks = callbacks;
							// callbacks is not null
							userName = ((NameCallback) callbacks[0]).getName();
							userPassword = String
									.valueOf(((PasswordCallback) callbacks[1])
											.getPassword());
						}
						if (userPassword == null
								|| userPassword.trim().length() == 0) {
							if (debug.messageEnabled()) {
								debug.message("DataStore.process: Password is null/empty");
							}
							generaMensajeErrorUsuario(Constantes.USUARIO_PASSWORD_INCORRECTO);
							return STATE_ENTRADA_PRINCIPAL;

						}
						// store username password both in success and failure
						// case
						storeUsernamePasswd(userName, userPassword);
						if (debug.messageEnabled()) {
							debug.message("getRequestOrg() -> "
									+ getRequestOrg());
							debug.message("Buscando al usuario con identificador libre "
									+ userName);
						}
						// Nota: El identificador de entrada es el introducido
						// en el form
						// en el callback se pasa el RDN/identificador del
						// usuario dentro del datastore
						// Se guarda para despues recuperarlo en caso de
						// error...

						identificadorEntrada = ((NameCallback) idCallbacks[0])
								.getName();

						// Pattern p = Pattern.compile("[^A-Za-z0-9.@_-~#]+");
					     
						validateUserName(identificadorEntrada, "^\\w+([\\.]?\\w+)*"); // TODO: configurar la expresión regular en un parámetro.
						/*
						 if (!Pattern.matches("^\\w+([\\.]?\\w+)*", identificadorEntrada)){
								debug.message(" identificador " + identificadorEntrada +" posee caracteres no válidos");
								generaMensajeErrorUsuario(Constantes.USUARIO_PASSWORD_INCORRECTO);
								return STATE_ENTRADA_PRINCIPAL;
						 }
				*/
	
						
						AMIdentityRepository idrepo = getAMIdentityRepository(getRequestOrg());

						// Fin captura user/passw

						HashMap<String, String> atributosUserPass = new HashMap<String, String>();
						atributosUserPass.put("IDENTIFICADOR", userName);

						// Buscando al usuario en el datastore

						AfirmaPrincipal usuarioP = getIDUserInDatastore(atributosUserPass);
						// authenticatedUser = usuarioP.getUid();
						if (debug.messageEnabled()) {
							debug.message("Logando al usuario con Identificador "
									+ usuarioP.getName());
						}

						((NameCallback) idCallbacks[0]).setName(usuarioP
								.getName());

						// autenticando al usuario en el datastore...

						boolean success = idrepo.authenticate(idCallbacks);

						if (success) {
							validatedUserID = userName;
							principal = usuarioP;
							return ISAuthConstants.LOGIN_SUCCEED;
						} else {
							principal = null;
							generaMensajeErrorUsuario(Constantes.USUARIO_PASSWORD_INCORRECTO);
							((NameCallback) idCallbacks[0])
									.setName(identificadorEntrada);
							return STATE_ENTRADA_PRINCIPAL;
						}

					} catch (InvalidPasswordException ex) {
						((NameCallback) idCallbacks[0])
								.setName(identificadorEntrada);
						debug.message("idRepo Exception", ex);
						// setFailureID(userName);
						generaMensajeErrorUsuario(Constantes.USUARIO_PASSWORD_INCORRECTO);
						return STATE_ENTRADA_PRINCIPAL;
					} catch (UserNamePasswordValidationException ex) {
					((NameCallback) idCallbacks[0])
							.setName(identificadorEntrada);
					debug.message("idRepo Exception", ex);
					// setFailureID(userName);
					generaMensajeErrorUsuario(Constantes.USUARIO_PASSWORD_INCORRECTO);
					return STATE_ENTRADA_PRINCIPAL;
				}					
				}

			case 2:
				debug.message("Submit desde la página de login por certificado");
				limpiarErrores();
				// limpiarSession();
				try {
					if ("1".equalsIgnoreCase(((String) super
							.getHttpServletRequest().getParameter("cancelar")))) {
						debug.message("El usuario ha cancelado la autenticación por certificados");

						return STATE_ENTRADA_PRINCIPAL;
					}
				} catch (Throwable e) {

				}
				debug.message("Submit desde la página de login por certificado");

				String signdata = super.getHttpServletRequest().getParameter(
						"signData");

				String desafio = (String) super.getHttpServletRequest()
						.getSession().getAttribute("desafio");

				if (debug.messageEnabled()) {
					debug.message("signdata -> " + signdata);
					debug.message("Desafio guardao en sesión ->" + desafio);
				}

				if (signdata != null && desafio != null
						&& !signdata.trim().equals("")
						&& !desafio.trim().equals("")) {

					principal = procesarAutenticacionCertificado(desafio,
							signdata);
					return ISAuthConstants.LOGIN_SUCCEED;
				} else {
					debug.message("No se han firmado Datos -> signdata="
							+ signdata + " desafio=" + desafio);
					generaMensajeErrorUsuario(Constantes.ERROR_AUTH_CERTIFICADOS);
					return STATE_ENTRADA_PRINCIPAL;

				}
			default: {
				return STATE_ENTRADA_PRINCIPAL;
			}
			}
		} catch (AuthFirmaException e) {
			debug.error("AuthFirmaException capturada");
			debug.error(e.getMessage(), e);
			generaMensajeErrorUsuario(e);
			return STATE_ENTRADA_PRINCIPAL;
		} catch (Throwable t) {
			debug.error("Error - Stage:" + state + "]");
			debug.error(t.getMessage(), t);
			generaMensajeErrorUsuario(Constantes.ERROR_GENERICO);
			return STATE_ENTRADA_PRINCIPAL;

		}

	}

	private AfirmaPrincipal procesarAutenticacionCertificado(
			String datosOrigen, String datosFirmados) throws AuthFirmaException {

		debug.message("Iniciando validación firma contra @firma");

		HashMap<String, String> atributosCertificado = validarFirma(
				datosOrigen, datosFirmados);

		debug.message("Buscando Identidad del Firmante en el Datastore");

		AfirmaPrincipal usuario = getIDUserInDatastore(atributosCertificado);
		debug.message("Usuario autenticado -> " + usuario.toString());
		// authenticatedUser = usuario.getUid();

		if (usuario == null) {
			throw new AuthFirmaException(Constantes.USUARIO_NO_EN_SISTEMA,
					"No se ha encontrado el usuario en el Sistema");
		}
		return usuario;
	}

	private AfirmaPrincipal getIDUserInDatastore(
			HashMap<String, String> atributosCertificado)
			throws AuthFirmaException {
		AfirmaPrincipal usuario = null;
		try {

			String nif = atributosCertificado.get("**NIF_CERTIFICADO**");
			String libre = atributosCertificado.get("IDENTIFICADOR");

			usuario = new AfirmaPrincipal();
			debug.message(" atributos ->  " + atributosCertificado);
			AMIdentityRepository idrepo = getAMIdentityRepository(getRequestOrg());

			// Inicializando campos de búsqueda en el datastore..
			Map valores = new HashMap<String, String>(); // campos de búsqueda
															// para la consulta
															// en el datastore

			if (nif != null && !nif.trim().equals("")) { // Viene de
															// autenticación por
															// certificados
				debug.message("Preparando búsqueda para login con certificado");

				nif = nif.trim();

				// verificando que el identificador no esté en la lista de
				// bloqueados.
				Set nifBloqueados = (Set) this.currentConfig
						.get(Constantes.AFIRMA_SERVICE_CAMPOS_NIFS_BLOQUEADOS);
				if (nifBloqueados.contains(nif.toLowerCase())
						|| nifBloqueados.contains(nif.toUpperCase())) {
					debug.message("El nif "
							+ nif
							+ " está en la lista de NIFs bloqueados en el SSOWeb");
					throw new AuthFirmaException(
							Constantes.IDENTIFICADOR_BLOQUEADO,
							"Su NIF está bloqueado en el SSOWeb");

				}

				String campoNifDatastore = (String) ((Set) this.currentConfig
						.get(Constantes.AFIRMA_SERVICE_CAMPOS_NIF_DATASTORE))
						.iterator().next();
				debug.message("Se busca al usuario por el campo "
						+ campoNifDatastore + " del datastore");
				HashSet temp = new HashSet(2);
				temp.add(nif.toLowerCase());
				temp.add(nif.toUpperCase());
				valores.put(campoNifDatastore, temp);
			} else if (libre != null && !libre.trim().equals("")) { // autenticación
																	// por
																	// user/passw
				debug.message("Preparando búsqueda para login con Usuario/Password");

				libre = libre.trim();

				// verificando que el identificador no esté en la lista de
				// bloqueados.
				Set nifBloqueados = (Set) this.currentConfig
						.get(Constantes.AFIRMA_SERVICE_CAMPOS_NIFS_BLOQUEADOS);
				if (nifBloqueados.contains(libre.toLowerCase())
						|| nifBloqueados.contains(libre.toUpperCase())) {
					debug.message("El identificador "
							+ libre
							+ " está en la lista de identificadores Bloqueados por el SSOWeb");
					throw new AuthFirmaException(
							Constantes.IDENTIFICADOR_BLOQUEADO,
							"Su identificador está bloqueado en el SSOWeb");

				}

				Set campos = (Set) this.currentConfig
						.get(Constantes.AFIRMA_SERVICE_CAMPOS_LOGIN_DATASTORE);

				debug.message("CAMPOS -> " + campos);

				// Añadiendo los campos identificadores configurados
				if (campos != null && campos.size() > 0) {
					for (Iterator iterator = campos.iterator(); iterator
							.hasNext();) {
						String campo = (String) iterator.next();
						debug.message("Se busca al usuario por el campo "
								+ campo);
						HashSet a = new HashSet(3); // por si el datastore es
													// sensible a mayúsculas.
						a.add(libre);
						a.add(libre.toLowerCase());
						a.add(libre.toUpperCase());
						valores.put(campo, a);
					}
				} else {
					debug.message("No se han configurado campos, añadiento campos uid y cn por defecto.");
					HashSet temp = new HashSet(3);
					temp.add(libre);
					temp.add(libre.toLowerCase());
					temp.add(libre.toUpperCase());
					valores.put("uid", temp);
					valores.put("cn", temp);
				}

			}

			// atributos devueltos por la consulta... No se usan ya que se
			// solicita devolver todos los atributos
			Set atributosDevueltos = new HashSet<String>();
			atributosDevueltos.add("uid");
			atributosDevueltos.add("cn");
			atributosDevueltos.add("dn");

			IdSearchResults result = idrepo.searchIdentities(IdType.USER, "*",
					valores, true, 2, 6000, atributosDevueltos, true);

			Set resultados = result.getSearchResults();

			if (resultados.isEmpty()) {

				debug.message("No se ha encontrador la identidad en el datastore.....");

				throw new AuthFirmaException(
						Constantes.USUARIO_PASSWORD_INCORRECTO,
						"El usuario no existe en el sistema");

			}

			if (resultados.size() == 1) {

				debug.message("Se ha encontrado la identidad en el datastore.....");

				Map atributosIdentidad = ((AMIdentity) resultados.iterator()
						.next()).getAttributes();

				// DEBUG Atributos
				Set claves = atributosIdentidad.keySet();

				if (debug.messageEnabled()) {
					debug.message("Pintando atributos de la identidad recuperada del datastore.");
					String as = "";
					for (Iterator it2 = claves.iterator(); it2.hasNext();) {
						as = (String) it2.next();
						debug.message("\t CLAVE " + as + " valor= "
								+ atributosIdentidad.get(as));

					}
				}

				// FIN DEBUG Atributos

				// SetName se pone el campo de logín único dentro del
				// datastore...

				// TODO: hacerlo bien -> poner en la configuración atributos
				// para definir estos campos en el datastore, esto para otra
				// versión.
				try {
					usuario.setName(((Set<String>) atributosIdentidad.get((String) ((Set) this.currentConfig
							.get(Constantes.AFIRMA_SERVICE_CAMPO_RDN_DATASTORE))
							.iterator().next())).iterator().next());
				} catch (Throwable e) {
				}

				try {
					usuario.setNombre(((Set<String>) atributosIdentidad
							.get("givenname")).iterator().next());
				} catch (Throwable e) {
				}
				try {
					usuario.setApellido1(((Set<String>) atributosIdentidad
							.get("sn")).iterator().next());
				} catch (Throwable e) {
				}

				try {
					usuario.setApellido2(((Set<String>) atributosIdentidad
							.get("sn2")).iterator().next());
				} catch (Throwable e) {
				}

				try {
					usuario.setNif(((Set<String>) atributosIdentidad.get((String) ((Set) this.currentConfig
							.get(Constantes.AFIRMA_SERVICE_CAMPOS_NIF_DATASTORE))
							.iterator().next())).iterator().next());
				} catch (Throwable e) {
				}

				try {
					usuario.setAnagrama(((Set<String>) atributosIdentidad
							.get("anagramafiscal")).iterator().next());
				} catch (Throwable e) {
				}

				try {
					usuario.setMail(((Set<String>) atributosIdentidad
							.get("mail")).iterator().next());
				} catch (Throwable e) {
				}

				try {
					usuario.setUid(((Set<String>) atributosIdentidad.get("uid"))
							.iterator().next());
					debug.message("\t UID de la identidad logada"
							+ atributosIdentidad.get("uid"));

					// authenticatedUser = (String)
					// atributosIdentidad.get("uid");

				} catch (Throwable e) {
				}

				return usuario;

			} else {
				debug.message("Se han encontrado varias cuentas asociadas a la Credencial Introducida, seleccione otro mecanismo de autenticación.....");

				throw new AuthFirmaException(
						Constantes.IDENTIFICADOR_DUPLICADO,
						"Se han encontrado varias cuentas asociadas a la Credencial Introducida, seleccione otro mecanismo de autenticación más restrictivo como el identificador de Correo");

			}
		} catch (SSOException e) {
			e.printStackTrace();
			throw new AuthFirmaException(Constantes.ERROR_GENERICO, e);
		} catch (IdRepoException e) {
			e.printStackTrace();
			throw new AuthFirmaException(Constantes.ERROR_GENERICO, e);
		}

	}

	public HashMap<String, String> validarFirma(String datosOrigen,
			String datosFirmados) throws AuthFirmaException {
		try {
			String certificadoRecuperado;

			// String appId = "des_ssoweb_integracion";

			String signFormat = "CADES";

			debug.message("Validando firma con plataforma @Firma");
			ValidarFirma vf = new ValidarFirma();

			certificadoRecuperado = vf.getValidatedCertificate(datosFirmados,
					signFormat, datosOrigen);

			debug.message("Solicitando información del certificado de firma");
			ObtenerInfoCertificado oic = new ObtenerInfoCertificado();

			debug.message("Parseando datos del certificado y buscando IDentificador");
			HashMap<String, String> certificateValues = oic
					.getInfoNodeFromCertificate(certificadoRecuperado);

			// TODO recorrer valores del campo de configuración para nif del
			// certificado y obtener el nif...

			String nif = null;
			Set campos = (Set) this.currentConfig
					.get(Constantes.AFIRMA_SERVICE_CAMPOS_NIF_CERTIFICADO);
			debug.message("Buscando campos " + campos
					+ " dentro del certificado");
			if (campos != null && campos.size() > 0) {
				for (Iterator iterator = campos.iterator(); iterator.hasNext();) {
					String key = (String) iterator.next();
					debug.message("Buscando el campo " + key
							+ " dentro del certificado");
					nif = certificateValues.get(key);
					if (nif == null || nif.trim().equals("")) {
						nif = certificateValues.get(key.toLowerCase());
						if (nif == null || nif.trim().equals("")) {
							nif = certificateValues.get(key.toUpperCase());

						}
					}
					if (nif != null) {
						debug.message("Campo "
								+ key
								+ " encontrado dentro del certificado con valor "
								+ nif);
						break;
					}
				}
			} else
				throw new AuthFirmaException(Constantes.ERROR_GENERICO,
						"No se ha configurado el parámetro AFIRMA_SERVICE_CAMPOS_NIF_CERTIFICADO");

			if (nif != null && !nif.trim().equals("")) {
				certificateValues.put("**NIF_CERTIFICADO**", nif);
				return certificateValues;

			} else {
				debug.message("No se ha localizado el campo NIF dentro del certificado de usuario");
				throw new AuthFirmaException(Constantes.CERTIFICADO_NO_VALIDO,
						"No se ha localizado el campo NIF dentro del certificado de usuario");
			}
		} catch (Exception e) {

			throw new AuthFirmaException(Constantes.ERROR_GENERICO,
					e.getMessage(), e);
		}

	}

	private void generaMensajeErrorUsuario(AuthFirmaException exception) {

		generaMensajeErrorUsuario(exception.getCodigo());
	}

	private void generaMensajeErrorUsuario(String codError) {

		String msg = "";
		try {
			msg = bundle.getString(codError);
		} catch (Throwable e) {
			debug.error(
					"Error: el codigo de error "
							+ codError
							+ " no se encuentra definido en el fichero de propiedades ",
					e);
			msg = bundle.getString(Constantes.ERROR_GENERICO);
		}

		debug.message("Generando error, codigo=" + codError + " msg=" + msg);
		super.getHttpServletRequest().getSession()
				.setAttribute("errorCode", codError);
		super.getHttpServletRequest().getSession()
				.setAttribute("errorMSG", msg);
		super.getHttpServletRequest()
				.getSession()
				.setAttribute("goto",
						super.getHttpServletRequest().getParameter("goto"));
		super.getHttpServletRequest()
				.getSession()
				.setAttribute(
						"gotoOnFail",
						super.getHttpServletRequest()
								.getParameter("gotoOnFail"));
		super.getHttpServletRequest()
				.getSession()
				.setAttribute(
						"SunQueryParamsString",
						super.getHttpServletRequest().getParameter(
								"SunQueryParamsString"));
		super.getHttpServletRequest()
				.getSession()
				.setAttribute("encoded",
						super.getHttpServletRequest().getParameter("encoded"));
	}

	private void limpiarErrores() {
		debug.message("Limpiando errores de sesion");
		super.getHttpServletRequest().getSession().removeAttribute("errorCode");
		super.getHttpServletRequest().getSession().removeAttribute("errorMSG");

	}

	private void limpiarSession() {
		debug.message("Limpiando datos sesion");
		super.getHttpServletRequest().getSession().removeAttribute("errorCode");
		super.getHttpServletRequest().getSession().removeAttribute("errorMSG");
		super.getHttpServletRequest().getSession().removeAttribute("goto");
		super.getHttpServletRequest().getSession()
				.removeAttribute("gotoOnFail");
		super.getHttpServletRequest().getSession()
				.removeAttribute("SunQueryParamsString");
		super.getHttpServletRequest().getSession().removeAttribute("encoded");

	}

	@Override
	public Principal getPrincipal() {
		debug.message("Pidiendo el principal ");

		if (principal != null) {
			debug.message("Pidiendo el principal " + principal);
			return (Principal) principal.clone();

		}
		return null;
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	public void destroyModuleState() {
		debug.message("destroyModuleState ()");
		principal = null;
		limpiarSession();
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	public void nullifyUsedVars() {
		debug.message("nullifyUsedVars() ");
		currentConfig = null;
		sharedState = null;
		limpiarSession();
	}

}
