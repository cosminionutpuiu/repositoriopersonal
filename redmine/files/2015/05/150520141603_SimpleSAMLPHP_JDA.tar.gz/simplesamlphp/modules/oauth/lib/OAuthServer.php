<?php

require_once(dirname(dirname(__FILE__)) . '/libextinc/OAuth.php');

/**
 * OAuth Provider implementation..
 *
 * @author Andreas Åkre Solberg, <andreas.solberg@uninett.no>, UNINETT AS.
 * @package simpleSAMLphp
 * @version $Id: OAuthServer.php 1481 2009-04-30 11:01:48Z andreassolberg $
 */
class sspmod_oauth_OAuthServer extends OAuthServer {
	public function get_signature_methods() {
		return $this->signature_methods;
	}
}

