function printerMap(title, notes) {

			var format = new Mapea.Format.WMC({
				'layerOptions' : {
					buffer : 0
				}
			});
			var wmcText = null;

			try {
				wmcText = format.write(map);
			} catch (err) {
				wmcText = null;
				UtilsUI.showMessageWindow("Información",
						"Error al generar el fichero WMC: " + err,
						Ext.MessageBox.ERROR);
			}

			if (wmcText != null) {
				document.getElementById("idWmcTextFileToPrint").value = wmcText;
				document.getElementById("idTitlePrintWMC").value = title;
				document.getElementById("idNotesPrintWMC").value = notes;
				document.getElementById("idFormPrintWMC").submit();
			}
		}

		function printerMapToPdf(title, notes) {

			var format = new Mapea.Format.WMC({
				'layerOptions' : {
					buffer : 0
				}
			});
			var wmcText = null;

			try {
				wmcText = format.write(map);
			} catch (err) {
				wmcText = null;
				UtilsUI.showMessageWindow("Información",
						"Error al generar el fichero WMC: " + err,
						Ext.MessageBox.ERROR);
			}

			if (wmcText != null) {
				document.getElementById("idWmcTextFileToPrintPdf").value = wmcText;
				document.getElementById("idTitlePrintPdf").value = title;
				document.getElementById("idNotesPrintPdf").value = notes;
				document.getElementById("idFormPrintPdf").submit();
			}

		}

		function exportMap(resolution, formatImage) {

			var format = new Mapea.Format.WMC({
				'layerOptions' : {
					buffer : 0
				}
			});
			var wmcText = null;

			try {
				wmcText = format.write(map);
			} catch (err) {
				wmcText = null;
				UtilsUI.showMessageWindow("Información",
						"Error al generar el fichero WMC: " + err,
						Ext.MessageBox.ERROR);
			}

			var width = 500; //getWidthFromResolution(resolution);
			var heigth = 500; //getHeigthFromResolution(resolution);

			if (wmcText != null) {
				document.getElementById("idWmcTextFileToExport").value = wmcText;
				document.getElementById("idResolutionExport").value = resolution;
				document.getElementById("idWidthImage").value = width;
				document.getElementById("idHeightImage").value = heigth;
				document.getElementById("idFormatExport").value = formatImage;
				document.getElementById("idFormExportImageMap").submit();
			}
		}
		
		//Overriding zoomResultBbox because of avoiding map center when search sharing
		Mapea.Geosearch.zoomResultBbox = function() {
		    if (!Mapea.Geosearch.GEOSEARCH_SEARCHING && !Mapea.Geosearch.STREET_SEARCHING) {
		    	var f = window.location.href;
				var d1 = f.indexOf("search=");
		    	if (d1 == -1 || searchCenter){
			        var lefts = [];
			        var rights = [];
			        var tops = [];
			        var bottoms = [];
			        
			        var features;
			        if (Mapea.Geosearch.LAYER.hasSpatialResults()) {
			            features = Mapea.Geosearch.LAYER.spatialFeatures;
			        }
			        else {
			            features = Mapea.Geosearch.LAYER.textFeatures;
			        }
			        if (Mapea.Geosearch.SEARCHSTREET) {
			            features = features.concat(Mapea.Geosearch.LAYER.geocoderFeatures);
			        }
			        
			        if (features.length > 0) {
			            for (var i=0,ilen=features.length; i<ilen; i++)
			            {
			                var feature = features[i];
			                if (feature && feature.geometry)
			                {
			                    //var bounds = features[0].geometry.getBounds();
			                    var bounds = feature.geometry.getBounds();
			                    if (bounds)
			                    {
			                        lefts.push(bounds.left);
			                        rights.push(bounds.right);
			                        tops.push(bounds.top);
			                        bottoms.push(bounds.bottom);
			                    }
			                }
			            }
			            var maxLeft = Math.min.apply(null, lefts);
			            var maxRight = Math.max.apply(null, rights);
			            var maxTop = Math.max.apply(null, tops);
			            var maxBottom = Math.min.apply(null, bottoms);
			            
			            var envolvedBbox = new OpenLayers.Bounds(maxLeft, maxBottom, maxRight, maxTop);
			            if (envolvedBbox && (envolvedBbox != null)) {
			                map.zoomToExtent(envolvedBbox);
			            }
			        }
		        }
		    }
		};
	    
