/* Copyright (c) 2006-2008 MetaCarta, Inc., published under the Clear BSD
 * license.  See http://svn.openlayers.org/trunk/openlayers/license.txt for the
 * full text of the license. */

/**
 * @requires OpenLayers/Control.js
 */

 /**
 * Class: CDAU.Control.PrintMap
 * Restore the unsaved feature's values to to the last saved values
 *
 * Inerits from:
 *  - <OpenLayers.Control>
 */
	Mapea.Control.ShareMapCDAU = OpenLayers.Class(OpenLayers.Control.Permalink, {
    


    CLASS_NAME: "Mapea.Control.ShareMapCDAU"
});
	
function createSharePanel(share, map) {
    var activo = false;
    var printPanel;

    var sharePanel = new OpenLayers.Control.Panel({displayClass:'CDAUShareMap', id:'shareMapPanelId'});
    
    
    //Añadimos el control a la barra de herramientas
    sharePanel.addControls(share);
    map.addControl(sharePanel);
    var leftPanel = map.leftPanel;
    panel = jQuery(leftPanel).find(".left-controls").get(0);
    panel.appendChild(sharePanel.div);
    
    onButton = function(evt) {
		
//	    var isShareCtrl = (evt.buttonElement.className && (evt.buttonElement.className.toLowerCase().indexOf("sharemap") > -1));
//	    if (isShareCtrl)
//	    {
	    var f = window.location.protocol + "//" +  window.location.host +  window.location.pathname;
		var d = f.indexOf("#");

		if (d != -1) {
			f = f.substring(0, d);
		}
		var p = $("#permalink").attr("href");
		//Eliminamos el parametro layers
		var e = p.indexOf("layers=");
		if (p != -1) {
			p = p.substring(0, e-1);
		}
		f += p;

		if (sigcMap.getOlmap().layers[0].name.indexOf("brido") > -1) {
			f += "&map=hibrido";
		} else {
			if (sigcMap.getOlmap().layers[0].name.indexOf("lite") > -1) {
				f += "&map=satelite";
			} else {
				f += "&map=callejero";
			}
		}
		//Añadimos la cadena de búsqueda (si la hay)
		var searchInput = $('#idInputSearchMobile')[0].value;
		if (searchInput != null && searchInput != ''){
			f += "&search=" + searchInput;
		}
		f = f.replace("?", "");
		document.getElementById("idShareText").value = f;
		Mapea.Util.showJQueryDialog('sharediv');
//	    }
	
		OpenLayers.Event.stop(evt ? evt : window.event);
    };
    
    if (Mapea.Util.isMobile) {
    	sharePanel.div.addEventListener('touchend',onButton);
    }
    else {
       
    	sharePanel.div.addEventListener('click',onButton);
    }
    
}