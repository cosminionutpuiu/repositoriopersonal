/* Copyright (c) 2006-2008 MetaCarta, Inc., published under the Clear BSD
 * license.  See http://svn.openlayers.org/trunk/openlayers/license.txt for the
 * full text of the license. */

/**
 * @requires OpenLayers/Control.js
 */

 /**
 * Class: CDAU.Control.PrintMap
 * Restore the unsaved feature's values to to the last saved values
 *
 * Inerits from:
 *  - <OpenLayers.Control>
 */
	Mapea.Control.PrintMapCDAU = OpenLayers.Class(OpenLayers.Control, {
    

    /**
    * Constructor: CDAU.Control.PrintMap
    *
    * Parameters:
    * options - {Object} An optional object whose properties will be set on
    *                    the control
    * requestFormat - {String} Format of the expected server response
    *
    */
    initialize: function(options) {
        this.handlers = {};
        OpenLayers.Control.prototype.initialize.apply(this, [options]);
        //this.handler = new OpenLayers.Handler.Click(this, {click: this.printMapAction});
    },


    /**
     * Method: printMapAction
     */
    printMapAction: function(evt) {
        
			
    },


    CLASS_NAME: "Mapea.Control.PrintMapCDAU"
});
	
function createPrintPanel(print, map) {
    var activo = false;
    var printPanel;

    var printPanel = new OpenLayers.Control.Panel({displayClass:'CDAUPrintMap', id:'printPanelId'});
    
	//Creación del control de impresión
	var layoutParams = {outputFilename : "CDAU_${yyyy-MM-dd_hhmmss}"};
	var pagesParams = {clientLogo : "http://www.juntadeandalucia.es/economiayhacienda/images/plantilla/logo_cabecera.gif",
			infoSRS : "\n" + Mapea.Util.getSRSDescription(map.projection), creditos : "Impresión del CDAU"
	};
	
	printerCtrl = new Mapea.Control.Printer("http://geoprint-sigc.juntadeandalucia.es/geoprint/pdf",
            layoutParams, pagesParams, {legend : false, fitMode: "closest"});
    this.map.addControl(printerCtrl);
  

	printPanel.onButtonClick = function(evt) {
	    var isPrintCtrl = (evt.buttonElement.className && (evt.buttonElement.className.toLowerCase().indexOf("printmap") > -1));
	    if (isPrintCtrl)
	    {
	        if (print.active)
	        {
	            printerCtrl.hideControl();
	        }
	        else
	        {
	            printerCtrl.showControl();
	        }
	    }
	
	    OpenLayers.Event.stop(evt ? evt : window.event);
	};
	
	printerCtrl.showControl = function(evt) {
        if (printerCtrl._showControl === false) {
        	$(".MapeaControlPrinter")[0].style.visibility = 'visible';
            // saves the minimized control height
            if (!Mapea.Util.printerMinHeight) {
                Mapea.Util.printerMinHeight = jQuery(printerCtrl.div).outerHeight(true);
            }
            
            OpenLayers.Element.addClass(printerCtrl.div, "hover");
            
            // disables map events for mobile
            if (Mapea.Util.isMobile) {
//                Mapea.Util.disableNavControls(this.map);
            }
            
            printerCtrl._showControl = true;
//            OpenLayers.Event.stop(evt, true);
        }
        print.activate();
    };
    
    printerCtrl.hideControl = function(evt) {
        if (printerCtrl._showControl === true) {
            OpenLayers.Element.removeClass(printerCtrl.div, "hover");
                
            // loses focus for mobile devices
            if (Mapea.Util.isMobile) {
                jQuery(printerCtrl.div).find("button.print").focus();
            }
            
            printerCtrl._showControl = false;
        }
        
        // resize zoom controls and searches
        Mapea.Util.adjustZoomControls(map);
        Mapea.Util.centerSearchDialog();
        $(".MapeaControlPrinter")[0].style.visibility = 'hidden';
        print.deactivate();
    };
    $('.minimize').remove();
    var minimizeDiv = Mapea.Util.createDiv("minimize");
    minimizeDiv.setAttribute("title", "Minimizar el control de impresión");
    minimizeDiv.addEventListener("click", printerCtrl.hideControl);
    $(".MapeaControlPrinter")[0].appendChild(minimizeDiv);
	//Añadimos el control a la barra de herramientas
	printPanel.addControls(print);
	map.addControl(printPanel);
	var leftPanel = map.leftPanel;
    panel = jQuery(leftPanel).find(".left-controls").get(0);
    panel.appendChild(printPanel.div);
}