$:.push File.expand_path('../lib', __FILE__)
require 'hrack'
