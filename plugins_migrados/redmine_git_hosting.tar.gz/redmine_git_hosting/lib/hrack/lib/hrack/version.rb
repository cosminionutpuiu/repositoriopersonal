module Hrack
  VERSION = '1.0.0'
end
