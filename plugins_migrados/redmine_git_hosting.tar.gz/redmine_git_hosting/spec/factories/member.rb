FactoryGirl.define do

  factory :member do |member|
  end

end
